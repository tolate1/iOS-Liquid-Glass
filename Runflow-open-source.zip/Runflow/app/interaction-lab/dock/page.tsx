'use client';
import {useEffect,useState} from 'react';
import GlassNavigation from '../../../components/GlassNavigation';
import GlassNavigationL48 from '../../../components/GlassNavigationL48';
import RunflowGlass from '../../../components/RunflowGlass';
import './dock.css';
import './legacy-dock.css';
const tabs=[['Обзор','Первая'],['Прогресс','Центральная'],['Цели и уровни','Последняя']];
export default function DockReview(){
 const [variant,setVariant]=useState('both'),[tab,setTab]=useState('Тренировки'),[backdrop,setBackdrop]=useState('lines'),[theme,setTheme]=useState('dark'),[commits,setCommits]=useState(0);
 useEffect(()=>{document.documentElement.dataset.theme=theme},[theme]);
 const change=(value:string)=>{setTab(value);setCommits(n=>n+1)};
 return <div className="app dock-review"><RunflowGlass/><main>
  <a href="/interaction-lab">← Проверка взаимодействий</a><h1>Dock · L48 / L49</h1>
  <div className="dock-review-controls">
   <div role="group" aria-label="Версия">{[['l48','A · L48'],['l49','B · L49'],['both','Рядом']].map(([v,l])=><button key={v} aria-pressed={variant===v} onClick={()=>setVariant(v)}>{l}</button>)}</div>
   <div role="group" aria-label="Тема">{[['dark','Тёмная'],['light','Светлая']].map(([v,l])=><button key={v} aria-pressed={theme===v} onClick={()=>setTheme(v)}>{l}</button>)}</div>
   <div role="group" aria-label="Положение">{tabs.map(([v,l])=><button key={v} aria-pressed={tab===v} onClick={()=>setTab(v)}>{l}</button>)}</div>
   <div role="group" aria-label="Фон">{[['lines','Линии'],['text','Текст'],['card','Карточка'],['numbers','Числа'],['black','Чёрный'],['white','Белый']].map(([v,l])=><button key={v} aria-pressed={backdrop===v} onClick={()=>setBackdrop(v)}>{l}</button>)}</div>
  </div>
  <div className="dock-review-pair">{(variant==='both'?['l48','l49']:[variant]).map(v=><section key={v}>
   <h2>{v==='l48'?'A · L48':'B · L49'}</h2>
   <div className={'dock-review-scene backdrop-'+backdrop}>
    <div className="dock-review-content" aria-hidden="true"><div className="dock-review-scroll">{backdrop==='numbers'?Array.from({length:14},(_,i)=><p key={i} className="diagnostic-numbers"><span>Спред 0,12</span><span>10,55 км/ч</span><span>CV 1,25%</span></p>):backdrop==='text'?Array.from({length:9},(_,i)=><p key={i}>Runflow 0123456789 · Темп · круги · 0123456789<br/>Дистанция · стабильность · Runflow 0123456789</p>):backdrop==='lines'?<svg viewBox="0 0 370 260" preserveAspectRatio="none"><path d="M0 200 L60 140 L120 180 L180 80 L240 130 L300 50 L370 100 M0 50 L370 250 M0 250 L370 50" fill="none" stroke="currentColor" strokeWidth="2"/>{[20,60,100,140,180,220].map(y=><path key={y} d={`M0 ${y}H370`} stroke="currentColor" strokeWidth=".5"/>)}</svg>:backdrop==='card'?<article><b>Вечерний стадион</b><p>2,40 км · 13:39</p><strong>10,55 км/ч</strong></article>:null}</div></div>
    {v==='l48'?<GlassNavigationL48 active={tab} count={7} onChange={change}/>:<GlassNavigation active={tab} count={7} onChange={change}/>}
   </div>
  </section>)}</div>
  <p role="status">Раздел: {tab}. Принято переключений: {commits}.</p>
  <p>Удерживай, веди к краю, меняй направление и отпускай. Во время перетаскивания раздел не меняется. Оба образца используют рабочие компоненты; данные тренировок не затрагиваются.</p>
  <p>SVG displacement проверяется отдельно от размытия. При неподдерживаемом фильтре используется прозрачный материал с blur; это не нативный рендерер Apple.</p>
 </main></div>;
}
