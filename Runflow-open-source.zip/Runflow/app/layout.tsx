import './globals.css';
import './ios-glass.css';
import './product-polish.css';
import './functional-glass.css';
import './material-system.css';
import './product-writing.css';
import './navigation-motion.css';
import './ios-polish-v36.css';
import './glass-interactions-v37.css';
import './workout-sheet.css';
import './dock-material.css';
export const viewport={width:'device-width',initialScale:1,viewportFit:'cover'};
export const metadata={title:'Runflow — беговой дневник',description:'Тренировки, круги и прогресс в беге.'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="ru" data-theme="dark" suppressHydrationWarning><body><script dangerouslySetInnerHTML={{__html:"try{document.documentElement.dataset.theme=localStorage.getItem('runflow-theme')==='light'?'light':'dark'}catch{}"}}/><div className="ambient-background" aria-hidden="true"/>{children}</body></html>}
