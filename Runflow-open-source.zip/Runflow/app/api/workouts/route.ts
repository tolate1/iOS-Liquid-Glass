import {getDb} from '../../../db';
import {workouts} from '../../../db/schema';
import {eq} from 'drizzle-orm';
export async function GET(){try{return Response.json((await getDb().select().from(workouts)).map(r=>JSON.parse(r.data)));}catch{return Response.json({error:'Не удалось загрузить записи'},{status:500});}}
export async function POST(req:Request){try{const w:any=await req.json();if(!w.id||!w.date||!Array.isArray(w.laps)||!w.laps.length||w.laps.some((l:any)=>!Number.isFinite(l.d)||!Number.isFinite(l.t)||l.d<=0||l.t<=0))return Response.json({error:'Проверьте дистанцию и время кругов'},{status:400});await getDb().insert(workouts).values({id:w.id,data:JSON.stringify(w)}).onConflictDoUpdate({target:workouts.id,set:{data:JSON.stringify(w)}});return Response.json({ok:true});}catch{return Response.json({error:'Не удалось сохранить тренировку'},{status:500});}}
export async function DELETE(req:Request){const {id}=await req.json() as {id:string};await getDb().delete(workouts).where(eq(workouts.id,id));return Response.json({ok:true});}
