import {getDb} from '../../../db';
import {settings} from '../../../db/schema';
import {eq} from 'drizzle-orm';
import {DEFAULT_GOALS,validGoals} from '../../../lib/goals';
export async function GET(){try{const [row]=await getDb().select().from(settings).where(eq(settings.id,'goals'));return Response.json(row?JSON.parse(row.data):DEFAULT_GOALS)}catch{return Response.json({error:'Не удалось загрузить цели'},{status:500})}}
export async function PUT(req:Request){try{const goals=await req.json();if(!validGoals(goals))return Response.json({error:'Укажите положительные дистанцию и время для обеих целей'},{status:400});await getDb().insert(settings).values({id:'goals',data:JSON.stringify(goals)}).onConflictDoUpdate({target:settings.id,set:{data:JSON.stringify(goals)}});return Response.json(goals)}catch{return Response.json({error:'Не удалось сохранить цели'},{status:500})}}
