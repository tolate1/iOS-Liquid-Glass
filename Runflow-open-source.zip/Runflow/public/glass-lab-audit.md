# Runflow: optical material audit and isolated acceptance lab

Date: 2026-11-11. Base application: version 24. This change adds `/glass-lab`; it does not integrate a new material into the main UI. No workout data, formulas, database or navigation interaction changes.

## Component/source map

| Component | Source | Optical path | Limitation |
| --- | --- | --- | --- |
| Shared functional surfaces | `components/RunflowGlass.tsx` | Per-size PNG displacement maps, feImage → feDisplacementMap → backdrop-filter; 1.8px preblur | Chromium-only candidate. The capability helper checks UA/CSS syntax, not rendered pixels. Fallback is blur. |
| Header, period filters, settings, segmented choices, mobile dock | selectors in `RunflowGlass.tsx`, `app/ios-glass.css`, `app/product-polish.css` | Shared real compositor backdrop when supported | Most elements sit over uniform surfaces; nested filtered ancestors can further reduce visible detail. Class markers alone do not prove a visible effect. |
| Desktop dock | last desktop rule in `app/product-polish.css` | backdrop-filter forced to none on outer navigation | The enclosing desktop nav is intentionally not an optical lens. |
| Moving selected navigation indicator | `components/GlassNavigation.tsx`, `.glass-lens*` CSS | Motion springs, pointer capture, lift/stretch; CSS surface | Geometry does not prove full-page optical refraction. Existing motion retained. |
| Cards/charts/table | page and product styles | ordinary content surfaces | Intentionally not optical. |
| Old WebGL experiment | `app/glass-research/page.tsx`, `research/liquid-glass/GlassRenderer.ts`, `GlassShader.ts` | html2canvas reconstructs DOM → uploaded texture → GPU shader | Reconstructed limited scene, delayed updates, CSS fidelity limitations. Never a compositor snapshot. |
| New DOM lab | `app/glass-lab/page.tsx`, `lab.css` | real grid/text/figures DOM backdrop → SVG displacement, no preblur | Visually verified refraction in this Chromium; no Safari claim. Displacement scale capped at 24 CSS px; map normalization remains source-dependent. |
| New Canvas lab | same route and existing GlassRenderer | visible Canvas2D source → exact same canvas texture → WebGL overlay | Not a solution for arbitrary Runflow DOM. WebGL unavailable in current browser; shader/hardware visual acceptance remains blocked. |

## Rendering and interaction

DOM lab has clear grid lines, coloured geometric calibration objects, editable live text, straight graph and draggable capsule. Colour is confined to the diagnostic chart, not the monochrome product. An optical toggle exposes the unchanged source. Frosted mode is explicitly labelled non-refractive.

The controller retains existing SpringValue physics, primary pointer/id filtering, pointer capture, cancel handling, arrow controls and reduced motion handling. Signed velocity drives skew (DOM path), signed shader geometry (WebGL path), stretch and highlight angle. The two renderers are different approximations, not proven optical parity. SVG maps are updated on quantized size changes, not each translation. WebGL textures upload only on scene/size/theme changes; moving the lens samples the existing texture. DPR capped at 3 for bounded memory. Context loss/restoration handlers rebuild the WebGL renderer and reupload the source; this lifecycle is implemented but cannot be exercised without a context here. Renderer.draw gained an optional shadow parameter defaulting to its prior .25; the lab passes zero so the shader output outside the lens remains transparent. Legacy page retains prior defaults.

## Evidence from this environment

- Chromium: real DOM text/grid is visibly displaced inside the lens. Not ordinary blur. Light and dark states inspected, pointer movement verified, optical off and forced frosted state verified.
- WebGL2: context creation returned null. No shader compile/link/render proof and no GPU timing. No hardware performance claim.
- RAF p95 can include throttled/background samples (observed ~1016ms vs active ~16.8ms); these numbers must not be labelled stable device FPS. Upload timings are CPU-side submission, not GPU completion.
- Physical iPhone 12 Safari: NOT tested.
- Continuous video: NOT captured in this environment. Still images prove neither animation smoothness nor device performance.
- No new optical integration into Runflow. Original application appearance retained.

## Official reference comparison

Sources: Apple [Meet Liquid Glass, WWDC25 219](https://developer.apple.com/videos/play/wwdc2025/219/) and [HIG Materials](https://developer.apple.com/design/human-interface-guidelines/materials).

Apple describes a functional layer for controls/navigation above content, dynamic response, Regular/Clear variants, and avoiding material stacked on material. The lab tests backdrop displacement and direct manipulation only. It does not reproduce Apple's full adaptive native lighting, reflection/environment response, material merging or guaranteed motion/performance. No numerical percentage of Apple similarity is justified.

## Acceptance gate, still open

1. Open `/glass-lab`, record baseline, lens over text/grid, slow/fast drag, reversal and release, both themes.
2. In WebGL mode require WebGL2/vertex/fragment/link success and visible same-source refraction; inspect DPR 2/3, resize, scrolling and context restoration.
3. Inspect any change outside capsule separately (no shadow in WebGL lab). Verify DOM grid and text stay sharp outside the capsule.
4. iPhone 12, standalone Safari: record exact iOS, diagnostic JSON and uninterrupted screen video. Check touch, labels, icons, frame intervals and texture latency. Software renderer does not pass hardware gate.
5. Only then select an integration strategy for real Runflow content. Canvas scene is not that strategy by itself; fallback is not refraction.

No automatic integration is authorized by passing syntax/math tests. Product-level integration remains pending successful material validation.
