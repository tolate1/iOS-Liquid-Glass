# Runflow

Open-source running diary with workout laps, pace and speed analytics, progress charts, goals and a Liquid Glass inspired interface.

Anyone may use, modify and redistribute this project under the MIT license. Keep the license and third-party notices when redistributing.

## Run locally

Requires Node.js 22.13+ and the pnpm version declared in package.json.

```sh
pnpm install --frozen-lockfile
pnpm dev
```

Open the local URL printed by the development server. Choose «Демо» to explore the interface without a database. The source does not include anyone's personal workout records.

## Database

The API uses a DB binding with the schema and migrations in db/ and drizzle/. For persistent workout storage, initialize the local database using the included SQL migrations. After `pnpm build`, the generated runtime configuration is in dist/server/wrangler.json. Apply each migration in order with `pnpm exec wrangler d1 execute DB --local --config dist/server/wrangler.json --file drizzle/<migration>.sql`.

The API is designed for a personal diary and does not include multi-user authorization. Add authentication and per-user data isolation before making a shared writable deployment.

## Checks

`pnpm typecheck`, `pnpm build`, `node scripts/check-lens-shape.mjs`, `node scripts/check-frame-spring.mjs`, `node scripts/check-glass-optics.mjs`, `node scripts/check-overview.mjs`, `node --experimental-strip-types --test tests/adaptive-glass-engine.test.ts`.

## Interface

The adaptive material comparison is at /glass-lab. It is experimental and separate from the main diary. Native iOS rendering parity is not claimed.

See THIRD_PARTY_NOTICES.md for attribution.
