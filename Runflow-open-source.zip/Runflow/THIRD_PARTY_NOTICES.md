# Third-party notices

The Liquid Glass displacement core includes MIT-licensed code from xinlingfeiwu/liquid-glass-design-skill. Its original LICENSE is retained alongside the core. Dependencies retain their own licenses; see their package metadata. The project license applies to the original Runflow contributions and does not replace third-party licenses.
