export function sampleVelocity(position:number,last:number,time:number,lastTime:number){return Math.max(-1000,Math.min(1000,(position-last)*1000/Math.max(8,time-lastTime)))}
export function releaseVelocity(speed:number,lastTime:number,now:number,cancelled:boolean,reduced:boolean){return cancelled||reduced||now-lastTime>=100?0:Math.max(-1000,Math.min(1000,speed))}
