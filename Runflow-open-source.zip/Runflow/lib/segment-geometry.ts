export function segmentPresentation(items:{left:number;width:number}[],center:number){
 const centers=items.map(b=>b.left+b.width/2);const c=Math.max(centers[0],Math.min(centers[centers.length-1],center));
 let i=0;while(i<items.length-2&&c>centers[i+1])i++;
 const j=Math.min(i+1,items.length-1),t=j===i?0:(c-centers[i])/(centers[j]-centers[i]);
 const width=items[i].width+(items[j].width-items[i].width)*t;
 return {left:c-width/2,width};
}
