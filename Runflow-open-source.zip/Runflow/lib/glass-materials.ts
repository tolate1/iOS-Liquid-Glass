/** Project profiles, not official Apple material constants. */
export type GlassLevel='surface'|'navigation'|'optical';
export const GLASS_PROFILES={
 surface:{maxScale:8,magnify:1.035,bend:.025,bezelRatio:.22,preblur:0},
 navigation:{maxScale:14,magnify:1.06,bend:.04,bezelRatio:.4,preblur:.15},
 optical:{maxScale:22,magnify:1.08,bend:.05,bezelRatio:.62,preblur:.35},
} as const;
export const SURFACE_SELECTOR='.app .dailyhero,.app .panel,.app .stats>article,.app .goalpreview,.app .modal';
export function materialLevel(el:Element):GlassLevel{
 if(el.matches(SURFACE_SELECTOR))return 'surface';
 if(el.matches('.app>aside,nav.motion-glass,.liquid-segment,.glass-select-trigger,.scalecontrol select'))return 'navigation';
 return 'optical';
}
