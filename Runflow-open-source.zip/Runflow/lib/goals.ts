export type Goal={distance:number;minutes:number};
export const DEFAULT_GOALS:Goal[]=[{distance:10.8,minutes:60},{distance:16.3,minutes:60}];
export function validGoals(value:unknown):value is Goal[]{return Array.isArray(value)&&value.length===2&&value.every(g=>g&&Number.isFinite(g.distance)&&g.distance>=.001&&g.distance<=1000&&Number.isFinite(g.minutes)&&g.minutes>=.01&&g.minutes<=10080)}
