/** Population CV of lap speeds, weighted by each lap's elapsed time. */
export function speedCV(laps:readonly {d:number;t:number}[]):number|null {
  if(laps.length<2||laps.some(l=>!Number.isFinite(l.d)||!Number.isFinite(l.t)||l.d<=0||l.t<=0))return null;
  const time=laps.reduce((s,l)=>s+l.t,0);
  const mean=laps.reduce((s,l)=>s+l.d,0)/time*3600;
  const variance=laps.reduce((s,l)=>s+l.t*Math.pow(l.d/l.t*3600-mean,2),0)/time;
  return Math.sqrt(variance)/mean*100;
}
