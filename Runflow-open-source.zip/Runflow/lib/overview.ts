import {speedCV} from './running-metrics';
export type OverviewRun={id:string;date:string;title:string;laps:{d:number;t:number}[]};
export const validRun=(w:OverviewRun)=>w.laps.length>0&&w.laps.every(l=>Number.isFinite(l.d)&&Number.isFinite(l.t)&&l.d>0&&l.t>0);
export const totalRun=(w:OverviewRun)=>({distance:w.laps.reduce((a,l)=>a+l.d,0),seconds:w.laps.reduce((a,l)=>a+l.t,0)});
const median=(v:number[])=>{const s=[...v].sort((a,b)=>a-b);return s.length?(s.length%2?s[(s.length-1)/2]:(s[s.length/2-1]+s[s.length/2])/2):null};
function aggregate(runs:OverviewRun[]){const totals=runs.map(totalRun),distance=totals.reduce((a,t)=>a+t.distance,0),seconds=totals.reduce((a,t)=>a+t.seconds,0);return {count:runs.length,distance,seconds,speed:seconds?distance/seconds*3600:null,cv:median(runs.map(w=>speedCV(w.laps)).filter((n):n is number=>n!==null)),days:new Set(runs.map(w=>w.date)).size}}
export function runningWeek(source:OverviewRun[]){
 const valid=source.filter(validRun).filter(w=>/^\d{4}-\d{2}-\d{2}$/.test(w.date)&&Number.isFinite(Date.parse(w.date+'T00:00:00Z'))).sort((a,b)=>a.date.localeCompare(b.date));
 if(!valid.length)return null;
 const latest=valid.at(-1)!,day=86400000,end=Date.parse(latest.date+'T00:00:00Z'),start=end-6*day;
 const at=(w:OverviewRun)=>Date.parse(w.date+'T00:00:00Z');
 const now=aggregate(valid.filter(w=>at(w)>=start&&at(w)<=end)),before=aggregate(valid.filter(w=>at(w)>=start-7*day&&at(w)<start));
 const frequency=Array.from({length:7},(_,i)=>valid.filter(w=>at(w)===start+i*day).length);
 return {now,before,frequency,start:new Date(start).toISOString().slice(0,10),end:latest.date,speedDelta:now.speed!==null&&before.speed!==null?(now.speed/before.speed-1)*100:null,volumeDelta:before.distance>0?(now.distance/before.distance-1)*100:null,cvDelta:now.cv!==null&&before.cv!==null?now.cv-before.cv:null};
}
export function assessmentReason(speedDelta:number,distanceDelta:number){
 const speed=.7*Math.log1p(speedDelta/100),distance=.3*Math.log1p(distanceDelta/100);
 if(!Number.isFinite(speed)||!Number.isFinite(distance))return 'Для объяснения нужны две тренировки с положительными дистанцией и скоростью.';
 if(Math.abs(speed)+Math.abs(distance)<1e-9)return 'Стабильная скорость и дистанция не изменились.';
 if(Math.abs(distance)>Math.abs(speed))return distanceDelta<0?'Главный фактор — меньшая дистанция. Даже при более высокой скорости короткая пробежка может получить меньший индекс.':'Главный фактор — большая дистанция: она сильнее повлияла на индекс, чем изменение скорости.';
 return speedDelta<0?'Главный фактор — снижение стабильной скорости с учётом разброса кругов.':'Главный фактор — рост стабильной скорости: он сильнее повлиял на индекс, чем изменение дистанции.';
}
