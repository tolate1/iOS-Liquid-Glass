/** Directional glass geometry. This approximates motion; it is not Apple's native material. */
export type LensCornerStyle='capsule'|'rounded';
export function lensShape(w:number,h:number,drive:number,pressure:number,horizontal:boolean,cornerStyle:LensCornerStyle='capsule'){
 const d=Math.max(-18,Math.min(18,drive)),p=Math.max(0,Math.min(1,pressure)),a=Math.abs(d);
 const width=Math.max(1,w+p*9+(horizontal?a*1.35:-a*.1));
 const height=Math.max(1,h+p*5+(horizontal?-a*.17:a*1.18));
 // Independent corner profile: selected iPhone tab is an oblong rounded rectangle,
 // not a circular bubble. The leading corners expand as the lens is pulled.
 const r=Math.min(width,height)*(cornerStyle==='rounded'?.34:.5);
 const lead=Math.max(5,r+d*.34),trail=Math.max(5,r-d*.34);
 return {width,height,offsetX:-(width-w)/2+(horizontal?d*.28:0),offsetY:-(height-h)/2+(horizontal?0:d*.28),skewX:horizontal?d*.24:0,skewY:horizontal?0:-d*.24,radius:horizontal?`${trail}px ${lead}px ${lead}px ${trail}px`:`${trail}px ${trail}px ${lead}px ${lead}px`,scale:1+p*.035,lightAngle:135+(horizontal?d*2:-d*2),lightX:50+(horizontal?d*1.8:0),lightY:35+(horizontal?0:d*1.8)};
}
