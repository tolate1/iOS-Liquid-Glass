/** Directional glass geometry. This approximates motion; it is not Apple's native material. */
export type LensCornerStyle='capsule'|'rounded'|'dock';
export function lensShape(w:number,h:number,drive:number,pressure:number,horizontal:boolean,cornerStyle:LensCornerStyle='capsule'){
 if(cornerStyle==='dock'&&horizontal){
  const d=Math.max(-18,Math.min(18,drive)),p=Math.max(0,Math.min(1,pressure));
  const width=Math.max(1,w+p*Math.min(2,w*.025)+Math.abs(d)*.3);
  const height=Math.max(1,h+p*.6-Math.abs(d)*.035),r=Math.min(width,height)/2;
  const lead=Math.max(1,r-Math.max(0,-d)*.12),trail=Math.max(1,r-Math.max(0,d)*.12);
  return {width,height,offsetX:-(width-w)/2+d*.12,offsetY:-(height-h)/2,
   skewX:0,skewY:0,radius:`${trail}px ${lead}px ${lead}px ${trail}px`,scale:1,
   lightAngle:135+d*1.5,lightX:50+d*1.2,lightY:25};
 }
 const d=Math.max(-18,Math.min(18,drive)),p=Math.max(0,Math.min(1,pressure)),a=Math.abs(d);
 const width=Math.max(1,w+p*Math.min(6,w*.06)+(horizontal?a*Math.min(.65,w*.007):-a*.05));
 const height=Math.max(1,h+p*Math.min(2,h*.035)+(horizontal?-a*.07:a*.35));
 // Independent corner profile: selected iPhone tab is an oblong rounded rectangle,
 // not a circular bubble. The leading corners expand as the lens is pulled.
 const r=Math.min(width,height)*(cornerStyle==='rounded'?.34:.5);
 const lead=Math.max(5,r+d*.34),trail=Math.max(5,r-d*.34);
 return {width,height,offsetX:-(width-w)/2+(horizontal?d*.28:0),offsetY:-(height-h)/2+(horizontal?0:d*.28),skewX:0,skewY:0,radius:horizontal?`${trail}px ${lead}px ${lead}px ${trail}px`:`${trail}px ${trail}px ${lead}px ${lead}px`,scale:1+p*.035,lightAngle:135+(horizontal?d*2:-d*2),lightX:50+(horizontal?d*1.8:0),lightY:35+(horizontal?0:d*1.8)};
}
