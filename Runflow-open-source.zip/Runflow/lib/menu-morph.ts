export type MenuRect={left:number;top:number;width:number;height:number};
export function menuMorph(p:number,source:MenuRect,target:MenuRect){
 const t=Math.max(0,Math.min(1,p)),mix=(a:number,b:number)=>a+(b-a)*t;
 const width=mix(source.width,target.width),height=mix(source.height,target.height);
 const x=mix(source.left,target.left)-target.left,y=mix(source.top,target.top)-target.top;
 return {x,y,sx:width/target.width,sy:height/target.height,clipLeft:Math.max(0,x),clipTop:Math.max(0,y),clipRight:Math.max(0,target.width-x-width),clipBottom:Math.max(0,target.height-y-height),opacity:Math.max(0,Math.min(1,(t-.22)/.55))};
}
