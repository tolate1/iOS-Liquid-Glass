/** Output-to-source displacement for a rounded, convex lens, in CSS pixels. */
export function glassDisplacement(u:number,v:number,w:number,h:number):[number,number]{
 const radius=Math.min(w,h)/2,bevel=Math.min(16,radius*.65);
 const qx=Math.abs(u)-(w/2-radius),qy=Math.abs(v)-(h/2-radius),ox=Math.max(qx,0),oy=Math.max(qy,0),len=Math.hypot(ox,oy),dist=len+Math.min(Math.max(qx,qy),0)-radius;
 if(dist>0||bevel<=0)return [0,0];
 let nx=0,ny=0;if(len){nx=ox/len*Math.sign(u);ny=oy/len*Math.sign(v)}else if(qx>qy)nx=Math.sign(u);else ny=Math.sign(v);
 const t=Math.max(.015,Math.min(1,-dist/bevel)),profile=Math.sqrt(1-(1-t)**2),slope=9*(1-t)/(bevel*profile),incidence=Math.atan(slope),refraction=Math.asin(Math.sin(incidence)/1.46),bend=Math.min(15,Math.tan(incidence-refraction)*(7+9*profile));
 const magnification=.095*Math.min(1,Math.max(0,-dist/4));return [-nx*bend-u*magnification,-ny*bend-v*magnification];
}
