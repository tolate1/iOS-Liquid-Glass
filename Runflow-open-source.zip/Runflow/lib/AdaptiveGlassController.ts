import {SpringValue} from '../research/liquid-glass/GlassPhysics';
import {createLiquidGlassDisplacementMap,supportsLiquidGlassSvgFilter} from '../components/liquid-glass/displacementMap';
import {ALL_GLASS_LAYERS,clampGlass,composeAdaptiveGlass,type GlassLayers,type GlassScene} from './adaptive-glass-engine';

const SVG_NS = 'http://www.w3.org/2000/svg';
let sequence = 0;

/**
 * One RAF updates geometry + mask + refractive strength + light + shadow.
 * An SVG backdrop filter is only a candidate on browsers that support it.
 * The fallbacks are explicitly non-refractive. No React setState per frame.
 */
export class AdaptiveGlassController {
  private width = new SpringValue(58, {stiffness: 260, damping: 28});
  private height = new SpringValue(46, {stiffness: 260, damping: 28});
  private press = new SpringValue(0, {stiffness: 420, damping: 29});
  private raf = 0;
  private lastFrame = 0;
  private expanded = false;
  private pressedPointer: number | null = null;
  private lastPointerX = 0;
  private lastPointerAt = 0;
  private pointerVelocity = 0;
  private touchX = .55;
  private touchY = .4;
  private layers: GlassLayers = {...ALL_GLASS_LAYERS};
  private readonly scene: GlassScene;
  private readonly shell: HTMLElement;
  private readonly material: HTMLElement;
  private readonly reducedMotion: MediaQueryList;
  private readonly reducedTransparency: MediaQueryList;
  private readonly increasedContrast: MediaQueryList;
  private readonly svg: SVGSVGElement;
  private readonly image: SVGFEImageElement;
  private readonly displacement: SVGFEDisplacementMapElement;
  private readonly filterId: string;
  private readonly svgCandidate: boolean;
  private mapScale = 0;
  private mapKey = '';
  private destroyed = false;

  constructor(shell: HTMLElement, material: HTMLElement, scene: GlassScene) {
    this.shell = shell;
    this.material = material;
    this.scene = scene;
    this.reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
    this.reducedTransparency = matchMedia('(prefers-reduced-transparency: reduce)');
    this.increasedContrast = matchMedia('(prefers-contrast: more)');
    this.svgCandidate = supportsLiquidGlassSvgFilter() &&
      !new URLSearchParams(location.search).has('glass-fallback');
    this.filterId = `age-optic-${++sequence}`;
    const svg = document.createElementNS(SVG_NS, 'svg');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('width', '0');svg.setAttribute('height', '0');
    svg.style.cssText = 'position:absolute;pointer-events:none;overflow:hidden';
    const filter = document.createElementNS(SVG_NS, 'filter');
    filter.setAttribute('id', this.filterId);
    filter.setAttribute('x', '0%');filter.setAttribute('y', '0%');
    filter.setAttribute('width', '100%');filter.setAttribute('height', '100%');
    filter.setAttribute('color-interpolation-filters', 'sRGB');
    const image = document.createElementNS(SVG_NS, 'feImage');
    image.setAttribute('result', 'map');image.setAttribute('width', '100%');
    image.setAttribute('height', '100%');image.setAttribute('preserveAspectRatio', 'none');
    const displacement = document.createElementNS(SVG_NS, 'feDisplacementMap');
    displacement.setAttribute('in', 'SourceGraphic');
    displacement.setAttribute('in2', 'map');
    displacement.setAttribute('xChannelSelector', 'R');
    displacement.setAttribute('yChannelSelector', 'G');
    filter.appendChild(image);filter.appendChild(displacement);svg.appendChild(filter);document.body.appendChild(svg);
    this.svg = svg;this.image = image;this.displacement = displacement;
    this.reducedMotion.addEventListener('change', this.onPreference);
    this.reducedTransparency.addEventListener('change', this.onPreference);
    this.increasedContrast.addEventListener('change', this.onPreference);
    shell.addEventListener('pointerdown', this.onPointerDown);
    shell.addEventListener('pointermove', this.onPointerMove);
    window.addEventListener('pointerup', this.onPointerEnd);
    window.addEventListener('pointercancel', this.onPointerEnd);
    window.addEventListener('blur', this.onWindowBlur);
    this.render(0, true);
  }

  private onPreference = () => {this.requestFrame()};
  private onWindowBlur = () => {this.pressedPointer = null;this.press.setTarget(0);this.pointerVelocity = 0;this.requestFrame()};
  private onPointerDown = (event: PointerEvent) => {
    if (!event.isPrimary || (event.pointerType === 'mouse' && event.button !== 0)) return;
    this.pressedPointer = event.pointerId;
    this.lastPointerX = event.clientX;
    this.lastPointerAt = performance.now();
    this.updateTouch(event);
    if (!this.reducedMotion.matches) this.press.setTarget(1);
    this.requestFrame();
  };
  private onPointerMove = (event: PointerEvent) => {
    if (event.pointerId !== this.pressedPointer) return;
    const time = performance.now();
    const dt = Math.max(8, time - this.lastPointerAt);
    this.pointerVelocity = clampGlass((event.clientX - this.lastPointerX) * 1000 / dt, -1500, 1500);
    this.lastPointerX = event.clientX;this.lastPointerAt = time;
    this.updateTouch(event);this.requestFrame();
  };
  private onPointerEnd = (event: PointerEvent) => {
    if (event.pointerId !== this.pressedPointer) return;
    this.pressedPointer = null;this.press.setTarget(0);this.pointerVelocity = 0;
    this.requestFrame();
  };
  private updateTouch(e: PointerEvent) {
    const rect = this.shell.getBoundingClientRect();
    this.touchX = clampGlass((e.clientX - rect.left) / Math.max(1, rect.width));
    this.touchY = clampGlass((e.clientY - rect.top) / Math.max(1, rect.height));
  }

  public setLayers(layers: GlassLayers) {this.layers = {...layers};this.requestFrame()}
  public setExpanded(value: boolean) {
    this.expanded = value;
    const targetWidth = 238;
    const targetHeight = 217;
    if (this.reducedMotion.matches || !this.layers.animation) {
      this.width.set(value ? targetWidth : 58);
      this.height.set(value ? targetHeight : 46);
    } else {
      this.width.setTarget(value ? targetWidth : 58);
      this.height.setTarget(value ? targetHeight : 46);
    }
    this.requestFrame();
  }
  public pulseKeyboard() {
    if (this.reducedMotion.matches) return;
    this.touchX = .5;this.touchY = .5;this.press.set(1);this.press.setTarget(0);this.requestFrame();
  }
  private requestFrame() {
    if (this.destroyed || this.raf) return;
    this.raf = requestAnimationFrame(this.tick);
  }
  private tick = (now: number) => {
    this.raf = 0;
    const dt = this.lastFrame ? (now - this.lastFrame) / 1000 : 1 / 60;
    this.lastFrame = now;
    if (this.reducedMotion.matches || !this.layers.animation) {
      this.width.set(this.expanded ? 238 : 58);
      this.height.set(this.expanded ? 217 : 46);
      this.press.set(0);
      this.pointerVelocity = 0;
    } else {
      this.width.step(dt);this.height.step(dt);this.press.step(dt);
      this.pointerVelocity *= Math.exp(-Math.min(dt, .1) * 14);
    }
    const settled = Math.abs(this.width.target - this.width.current) < .12 &&
      Math.abs(this.height.target - this.height.current) < .12 &&
      Math.abs(this.press.target - this.press.current) < .004 &&
      Math.abs(this.width.velocity) < .2 && Math.abs(this.height.velocity) < .2 &&
      Math.abs(this.press.velocity) < .02 && Math.abs(this.pointerVelocity) < 2;
    this.render(dt, settled);
    if (!settled) this.requestFrame();
    else this.lastFrame = 0;
  };

  private render(_dt: number, settled: boolean) {
    const width = this.width.current, height = this.height.current;
    const highContrast = this.increasedContrast.matches;
    const reducedTransparency = this.reducedTransparency.matches || highContrast;
    const frame = composeAdaptiveGlass({scene:this.scene,layers:this.layers,
      width,height,press:this.press.current,velocity:this.pointerVelocity,
      touchX:this.touchX,touchY:this.touchY,expanded:this.expanded,reducedTransparency,
      reducedMotion:this.reducedMotion.matches});
    const s = this.shell.style, m = this.material.style;
    s.width = `${width.toFixed(2)}px`;s.height = `${height.toFixed(2)}px`;
    s.transform = `scale(${frame.animation.scaleX.toFixed(4)},${frame.animation.scaleY.toFixed(4)}) rotate(${frame.animation.tilt.toFixed(2)}deg)`;
    s.borderRadius = `${frame.mask.radius.toFixed(2)}px`;
    s.setProperty('--age-radius', `${frame.mask.radius.toFixed(2)}px`);
    s.setProperty('--age-fg', frame.glass.foreground);
    s.setProperty('--age-tint', frame.glass.tint);
    s.setProperty('--age-reflect', frame.light.reflection);
    s.setProperty('--age-border', frame.light.border);
    s.setProperty('--age-light', String(frame.light.intensity));
    s.setProperty('--age-light-x',`${frame.light.x.toFixed(1)}%`);
    s.setProperty('--age-light-y',`${frame.light.y.toFixed(1)}%`);
    s.setProperty('--age-light-angle',`${frame.light.angle.toFixed(1)}deg`);
    s.setProperty('--age-lift',`${frame.shadow.lift.toFixed(1)}px`);
    s.setProperty('--age-shadow-opacity',String(frame.shadow.intensity));
    s.setProperty('--age-shadow-rgb',frame.shadow.color);
    this.shell.dataset.ageState = this.expanded ? 'expanded' : 'compact';
    this.shell.dataset.ageEnvironment = this.scene;
    const optical = this.layers.glass && !reducedTransparency;
    const svg = optical && this.svgCandidate;
    const fallback = optical && !svg;
    this.shell.dataset.ageOpticalPath = svg ? 'svg-candidate' : fallback ? 'blur-only' : 'off';
    if (settled && svg) this.updateMap(width, height, frame.mask.radius);
    if (svg && this.mapScale > 0) {
      const scale = Math.min(28,this.mapScale * frame.glass.strength);
      this.displacement.setAttribute('scale', scale.toFixed(3));
    }
    m.backdropFilter = svg && this.mapScale > 0 ? `url("#${this.filterId}")`
      : fallback ? `blur(${frame.glass.blur}px) saturate(1.2)` : 'none';
    m.setProperty('-webkit-backdrop-filter', m.backdropFilter);
    this.shell.dataset.ageFiveLayers = Object.values(this.layers).map(Number).join('');
    s.boxShadow = this.layers.shadow ?
      `0 ${frame.shadow.lift.toFixed(1)}px ${(19 + frame.shadow.lift).toFixed(1)}px rgb(${frame.shadow.color} / ${(frame.shadow.intensity*.46).toFixed(3)}), inset 0 1px 0 rgb(255 255 255 / .14)` : 'none';
    if (highContrast || this.reducedTransparency.matches) {
      m.background = this.scene === 'dark' ? 'rgb(43 51 70)' : 'rgb(248 250 254)';
    } else m.background = this.layers.glass ? frame.glass.tint : 'rgb(255 255 255 / .06)';
    if (!this.layers.light) s.setProperty('--age-light','0');
  }

  private updateMap(width: number, height: number, radius: number) {
    const w = Math.round(width/4)*4,h = Math.round(height/4)*4,r = Math.round(radius);
    const key = `${w}:${h}:${r}`;
    if (this.mapKey === key) return;
    const map = createLiquidGlassDisplacementMap({width:w,height:h,radius:r,
      profile:'soft',magnify:1.085,bend:.06,bezelRatio:.73,supersample:2});
    if (!map.url) return;
    this.image.setAttribute('href',map.url);this.mapScale = map.scale;
    this.mapKey = key;
  }

  public snapshot() {
    return {scene:this.scene,expanded:this.expanded,layers:this.layers,
      opticalPath:this.shell.dataset.ageOpticalPath ?? 'unavailable',
      svgCandidate:this.svgCandidate,
      reducedMotion:this.reducedMotion.matches,
      reducedTransparency:this.reducedTransparency.matches,
      increasedContrast:this.increasedContrast.matches,
      note:'svg-candidate не является подтверждением видимого преломления; blur-only рефракцией не считается.'};
  }
  public dispose() {
    this.destroyed = true;cancelAnimationFrame(this.raf);
    this.svg.remove();this.reducedMotion.removeEventListener('change',this.onPreference);
    this.reducedTransparency.removeEventListener('change',this.onPreference);
    this.increasedContrast.removeEventListener('change',this.onPreference);
    this.shell.removeEventListener('pointerdown',this.onPointerDown);
    this.shell.removeEventListener('pointermove',this.onPointerMove);
    window.removeEventListener('pointerup',this.onPointerEnd);
    window.removeEventListener('pointercancel',this.onPointerEnd);
    window.removeEventListener('blur',this.onWindowBlur);
  }
}
