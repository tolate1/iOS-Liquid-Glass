/**
 * Runflow adaptive material: a deterministic, testable contract between five
 * visual layers. This deliberately models four known laboratory environments;
 * it never claims to have sampled arbitrary HTML pixels under a lens.
 */
export type GlassScene = 'dark' | 'light' | 'color' | 'text';
export type GlassLayer = 'animation' | 'mask' | 'glass' | 'light' | 'shadow';
export type GlassLayers = Record<GlassLayer, boolean>;

export const ALL_GLASS_LAYERS: Readonly<GlassLayers> = {
  animation: true, mask: true, glass: true, light: true, shadow: true,
};

export const SCENE_PROFILES: Readonly<Record<GlassScene, {
  label: string; luminance: number; contrast: number; chroma: number;
  tint: string; foreground: string; border: string; reflection: string;
  shadowColor: string; blur: number; refract: number;
}>> = {
  dark: {
    label: 'Тёмный', luminance: .09, contrast: .5, chroma: .05,
    tint: 'rgba(238,244,255,.15)', foreground: '#f9fbff',
    border: 'rgba(255,255,255,.50)', reflection: '255 255 255',
    shadowColor: '14 21 38', blur: 13, refract: .84,
  },
  light: {
    label: 'Светлый', luminance: .91, contrast: .36, chroma: .03,
    tint: 'rgba(255,255,255,.52)', foreground: '#152035',
    border: 'rgba(255,255,255,.86)', reflection: '255 255 255',
    shadowColor: '53 64 85', blur: 14, refract: .79,
  },
  color: {
    label: 'Цветной', luminance: .53, contrast: .68, chroma: .9,
    tint: 'rgba(233,246,255,.27)', foreground: '#0d1c31',
    border: 'rgba(255,255,255,.68)', reflection: '212 241 255',
    shadowColor: '37 48 92', blur: 10, refract: 1.0,
  },
  text: {
    label: 'Текст и график', luminance: .72, contrast: .96, chroma: .19,
    tint: 'rgba(249,251,255,.74)', foreground: '#101c2c',
    border: 'rgba(255,255,255,.92)', reflection: '255 255 255',
    shadowColor: '28 39 65', blur: 12, refract: .68,
  },
};

export type AdaptiveFrameInput = {
  scene: GlassScene;
  layers: GlassLayers;
  width: number;
  height: number;
  press: number;
  velocity: number; // signed horizontal CSS px / second
  touchX: number; // normalized 0..1
  touchY: number;
  expanded: boolean;
  reducedTransparency?: boolean;
  reducedMotion?: boolean;
};

export const clampGlass = (n: number, low = 0, high = 1) =>
  Math.max(low, Math.min(high, Number.isFinite(n) ? n : low));

export function composeAdaptiveGlass(input: AdaptiveFrameInput) {
  const p = SCENE_PROFILES[input.scene];
  const press = clampGlass(input.press);
  const velocity = clampGlass(input.velocity / 1300, -1, 1);
  const speed = Math.abs(velocity);
  const expansion = clampGlass((input.width - 58) / 180);
  const visualExpansion = input.layers.animation ? expansion : (input.expanded ? 1 : 0);
  const touchX = clampGlass(input.touchX);
  const touchY = clampGlass(input.touchY);
  // All five outputs depend on the same physical state, not CSS timers.
  const maskRadius = input.layers.mask ? 15 + 9 * visualExpansion + press * 3 : 15;
  const scaleX = input.layers.animation && !input.reducedMotion ? 1 + .07 * press + .016 * speed : 1;
  const scaleY = input.layers.animation && !input.reducedMotion ? 1 - .052 * press + .007 * visualExpansion : 1;
  const opticStrength = input.layers.glass && !input.reducedTransparency
    ? clampGlass(p.refract * (.78 + .13 * visualExpansion + .075 * press + .075 * speed)) : 0;
  const lightIntensity = input.layers.light ? clampGlass(.50 + .20 * press + .16 * speed + .12 * visualExpansion) : 0;
  const shadowIntensity = input.layers.shadow ? clampGlass(.47 + .28 * visualExpansion + .14 * press + .04 * speed) : 0;
  const tilt = input.layers.animation && !input.reducedMotion ? clampGlass(velocity * 4.2, -4.2, 4.2) : 0;
  return {
    environment: p.label,
    features: {luminance: p.luminance, contrast: p.contrast, chroma: p.chroma},
    animation: {scaleX, scaleY, tilt, expansion: visualExpansion},
    mask: {radius: maskRadius},
    glass: {strength: opticStrength, blur: p.blur, tint: p.tint, foreground: p.foreground},
    light: {intensity: lightIntensity, x: touchX * 100, y: touchY * 100,
      angle: 110 + velocity * 31, border: p.border, reflection: p.reflection},
    shadow: {intensity: shadowIntensity, color: p.shadowColor, lift: 6 + 13 * visualExpansion + 3 * press},
  };
}
