// Animate the material bounds; foreground typography never receives a scale.
export function animateGlassMenu(el:HTMLElement,button:HTMLElement,open:boolean,width:number,height:number,left:number,top:number,previous:Animation|null,done:()=>void){
 const r=button.getBoundingClientRect(),style=getComputedStyle(el);
 const start=previous?{left:style.left,top:style.top,width:style.width,height:style.height,opacity:style.opacity,borderRadius:style.borderRadius}:null;
 previous?.cancel();
 const content=el.firstElementChild as HTMLElement|null;
 if(content){content.getAnimations().forEach(a=>{a.commitStyles();a.cancel()});content.style.width=Math.max(0,width-16)+'px';content.style.transform='none';content.style.animation='none';}
 const small={left:r.left+'px',top:r.top+'px',width:r.width+'px',height:r.height+'px',opacity:0,borderRadius:getComputedStyle(button).borderRadius};
 const full={left:left+'px',top:top+'px',width:width+'px',height:height+'px',opacity:1,borderRadius:'22px'};
 el.style.overflow='hidden';el.style.boxSizing='border-box';el.style.transform='none';
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 if(reduced){Object.assign(el.style,open?full:small);if(content)content.style.opacity=open?'1':'0';if(open)el.style.overflowY='auto';done();return null;}
 const a=el.animate([start??(open?small:full),open?full:small],{duration:open?290:220,easing:'cubic-bezier(.2,.82,.2,1)',fill:'both'});
 if(content){const opacity=start?getComputedStyle(content).opacity:open?'0':'1';content.animate([{opacity},{opacity:open?1:0}],{duration:open?180:75,delay:open?65:0,easing:'ease-out',fill:'both'});}
 a.onfinish=()=>{if(open)el.style.overflowY='auto';done()};return a;
}
