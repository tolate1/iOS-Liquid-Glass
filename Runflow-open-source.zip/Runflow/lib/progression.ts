import {speedCV} from './running-metrics';
export type Run={id:string;date:string;title:string;kind?:'continuous'|'interval';laps:{d:number;t:number}[]};
export type Weights={speed:number;distance:number;consistency:number};
export type Baseline={speed:number;distance:number;consistency:number;ids:string[];date:string};
export const DEFAULT_WEIGHTS:Weights={speed:45,distance:35,consistency:20};
export const mid=(a:number[])=>{const s=[...a].sort((a,b)=>a-b);return s.length?s.length%2?s[(s.length-1)/2]:(s[s.length/2-1]+s[s.length/2])/2:0};
export function features(w:Run){const cv=speedCV(w.laps);if(w.kind==='interval'||cv===null)return null;const distance=w.laps.reduce((s,l)=>s+l.d,0),time=w.laps.reduce((s,l)=>s+l.t,0);return {speed:distance/time*3600,distance,consistency:1/(1+cv/100),cv}}
export const ordered=(runs:Run[])=>[...runs].sort((a,b)=>a.date.localeCompare(b.date)||a.id.localeCompare(b.id));
export function makeBaseline(runs:Run[]):Baseline|null{const eligible=ordered(runs).filter(w=>features(w)!==null).slice(0,5);if(eligible.length<5)return null;const f=eligible.map(w=>features(w)!);return {speed:mid(f.map(x=>x.speed)),distance:mid(f.map(x=>x.distance)),consistency:mid(f.map(x=>x.consistency)),ids:eligible.map(w=>w.id),date:eligible[4].date}}
export function validWeights(x:any):x is Weights{return !!x&&['speed','distance','consistency'].every(k=>Number.isFinite(x[k])&&x[k]>=0&&x[k]<=100)&&Math.abs(x.speed+x.distance+x.consistency-100)<.001}
export function runIndex(w:Run,b:Baseline,weights:Weights){const f=features(w);if(!f)return null;return 100*Math.pow(f.speed/b.speed,weights.speed/100)*Math.pow(f.distance/b.distance,weights.distance/100)*Math.pow(f.consistency/b.consistency,weights.consistency/100)}
export function progressRows(runs:Run[],b:Baseline,weights:Weights){const eligible=ordered(runs).filter(w=>features(w)!==null);return eligible.map((w,i)=>{const f=features(w)!;return {id:w.id,date:w.date,name:w.date.slice(5).split('-').reverse().join('.'),title:w.title||'Пробежка',score:runIndex(w,b,weights)!,level:mid(eligible.slice(Math.max(0,i-4),i+1).map(r=>runIndex(r,b,weights)!)),speed:f.speed,distance:f.distance,cv:f.cv}})}
export function experience(runs:Run[]){const valid=runs.filter(w=>w.laps.length>0&&w.laps.every(l=>Number.isFinite(l.d)&&Number.isFinite(l.t)&&l.d>0&&l.t>0));const days=new Set(valid.map(w=>w.date)).size;const xp=valid.length*10+days*5;return {xp,level:1+Math.floor(xp/100),remaining:100-xp%100,runs:valid.length,days}}
