export type DockBox={left:number;top:number;width:number;height:number};
export const DOCK_SAFE_INSET=6;
const clamp=(v:number,min:number,max:number)=>Math.max(min,Math.min(max,v));

/** Button centres remain the selection anchors. Insets constrain presentation only. */
export function dockAnchor(button:DockBox,root:{width:number;height:number},horizontal:boolean){
 const inset=horizontal?DOCK_SAFE_INSET:0;
 const width=Math.max(1,Math.min(button.width,root.width-2*inset));
 const height=Math.max(1,Math.min(button.height,root.height-2*inset));
 return {x:clamp(button.left+button.width/2,inset+width/2,root.width-inset-width/2),
  y:clamp(button.top+button.height/2,inset+height/2,root.height-inset-height/2),width,height};
}

/** Constrain the *deformed* silhouette, not just its resting coordinate. */
export function dockPresentation(left:number,top:number,width:number,height:number,root:{width:number;height:number}){
 const inset=DOCK_SAFE_INSET;
 const w=Math.max(1,Math.min(width,root.width-2*inset));
 const h=Math.max(1,Math.min(height,root.height-2*inset));
 return {left:clamp(left,inset,root.width-inset-w),top:clamp(top,inset,root.height-inset-h),width:w,height:h};
}
