/** Partial, feathered content attenuation. No page reconstruction or opaque cut-out. */
export const DOCK_EDGE_PAD=24;
export const DOCK_CONTENT_ATTENUATION=.92;
export function dockSeparationMask(width:number,height:number){
 const w=Math.max(1,Math.round(width)),h=Math.max(1,Math.round(height)),pad=DOCK_EDGE_PAD;
 const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${w+pad*2}" height="${h+pad*2}" viewBox="0 0 ${w+pad*2} ${h+pad*2}"><defs><filter id="e" x="-50%" y="-100%" width="200%" height="300%"><feGaussianBlur stdDeviation="10"/></filter></defs><rect x="${pad}" y="${pad}" width="${w}" height="${h}" rx="${h/2}" fill="black" fill-opacity="${DOCK_CONTENT_ATTENUATION}" filter="url(#e)"/></svg>`;
 return {url:`url("data:image/svg+xml,${encodeURIComponent(svg)}")`,width:w+pad*2,height:h+pad*2};
}
