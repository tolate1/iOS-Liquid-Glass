export type NavHit={value:string;left:number;top:number;right:number;bottom:number};
// Pointer capture changes event targets. Select against the rendered button bounds.
export function navigationHit(x:number,y:number,buttons:NavHit[]){
 return buttons.find(b=>x>=b.left&&x<=b.right&&y>=b.top&&y<=b.bottom)?.value;
}
export function sameNavigationGeometry(a:number[],b:number[]){return a.length===b.length&&a.every((v,i)=>Math.abs(v-b[i])<.5)}
