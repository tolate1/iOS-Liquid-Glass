# Motion research — 2026-11-15

Source baseline: 84443b31f89b77162b33fb1c2818aa5c98cb8e77.

## Verified repositories
- emilkowalski/skills: gestures, apple-design, mobile-native, review-animations, improve-animations, learn-taste exist. improve-animations is an advisor/planner; learn-taste records corrections and does not implement motion.
- YordiLorenzo/liquid-glass-skills: apple-motion-feel and liquid-glass-motion exist. Native SwiftUI behavior is a reference, not a browser rendering implementation or official numeric specification.
- jakubkrehel/skills: state-machine is a component workbench, not a state-management library.
- GetStream/awesome-liquid-glass provides native slider, Tab Bar and menu samples. FradSer/FluidInterfacesSwiftUI provides direct manipulation and interruptible spring examples.
- LottieFiles/motion-design-skill describes motion intent/choreography. A cascading dashboard entrance conflicts with this owner's explicit preference and is not adopted.

## Current-code findings
1. hooks/useGlassDrag.ts uses segmentPresentation's clamped center. No boundary resistance is modeled. First prototype comparison: bounded resistance outside endpoint, without changing the committed selection. Numerical bounds tests currently test the hard clamp; do not silently invalidate them.
2. The hook releases to the nearest current center; velocity is passed to the spring but does not affect target selection. A projected endpoint may suit navigation, but the journal/demo data switch needs an explicit comparison before adopting flick-to-switch.
3. lib/animate-glass-menu.ts avoids scaling foreground labels but animates layout bounds. This trades typography correctness for layout cost. Profile it rather than claiming it is compositor-only. A separate transformed material sibling with a clipped, unscaled foreground is the next candidate.
4. Menu shell and content use separate timing/opacity animations. Interruption samples current state, but a single progress driver would make them easier to keep synchronized. No claim that changing opacity reproduces native materialize.
5. useGlassDrag and GlassNavigation still have separate gesture controllers. Reconcile cancel, resize, release velocity and stale-speed handling before sharing code; preserve distinct selection policies.

## Prototype workbench
/interaction-lab imports real GlassSegment, GlassNavigation and GlassSelect. One family is shown at a time. Local state and commit count make unintended data changes observable without touching the diary database. This is a baseline harness, not an improved Apple-equivalent renderer.

## Acceptance
Record identical slow/fast/reversed gestures, hold-then-drag, cancel, interrupted release, Escape/outside click, light/dark and reduced-motion scenarios. Measure frame intervals and layout cost independently. Phone hardware/GPU and Safari/Telegram observations are separate from desktop execution. No physical-device result is claimed here.

## References
https://github.com/emilkowalski/skills
https://github.com/YordiLorenzo/liquid-glass-skills
https://github.com/jakubkrehel/skills
https://github.com/GetStream/awesome-liquid-glass
https://github.com/FradSer/FluidInterfacesSwiftUI
https://github.com/LottieFiles/motion-design-skill

## Pinned source revisions
- emilkowalski/skills: 0f2e23b32bb1265e84cff8d3e75785fec953fb1b
- YordiLorenzo/liquid-glass-skills: a6bac94c5a7a65ac42207452e3e63bb4eb7518e8
- jakubkrehel/skills: a72290d140249813898ba8648becf6415abcb059
- GetStream/awesome-liquid-glass: a797c7a1c78373005961ad73e05d378f4dcb4b34
- FradSer/FluidInterfacesSwiftUI: 26d9220318944cdd37c18c2a8c59e5872bd3f7fc
- LottieFiles/motion-design-skill: f9a8a041b85185ee4881b3471d3415e939aac772

GetStream's Tab Bar and menu samples delegate rendering/interaction to SwiftUI TabView/Menu. They are native-reference examples, not a portable spring/morph algorithm to copy into React.


Desktop preview: candidate checkbox and segment value/commit count updated; real menu opened and selected 30 days; navigation keyboard selection updated the local route state. This checks plumbing, not continuous gesture smoothness, edge resistance feel or physical-device performance. No new continuous video recorded.

## Experiment iteration — separate material plane
- GlassSelect motionMode=layer keeps final-size panel/labels fixed and transforms a separate backdrop shell. One progress spring controls shell transform, content clip/opacity and shadow. Bounds mode remains the default baseline. These are two experiments, not a native Apple implementation.
- Segment and optional navigation candidate share velocity sampling/release freshness conventions; navigation retains its own tab choice policy. Candidate navigation adds bounded boundary resistance. Lifecycle ownership remains per component; this is not a claim that both complete controllers have been unified.
- InteractionMetrics samples 240 RAF intervals, p50/p95 and >25ms counts; optional long-animation-frame records report only forced style/layout attributed in slow frames. It is not total layout cost, GPU time or hardware proof. Compare on one device with identical gestures. Zero does not establish absence of layout.
- Six numerical tests cover menu endpoints, interrupted progress spring continuity/settling, stale/cancel/reduced velocity and segment geometry bounds. TypeScript passes. Local preview infrastructure refused the connection despite stale dev-server registration, so the current iteration requires published-page verification. No iPhone acceptance or continuous recording is claimed.

## Mobile navigation correction after owner video
The owner reports the lab Dock was nonfunctional on the phone; the recording is failure evidence, not an inconclusive acceptance. The desktop screenshot only establishes desktop selection. Changes: move the mobile specimen into a body portal outside its panel, keep exactly one mounted specimen, resolve pointer-up taps by button rectangles rather than elementFromPoint after capture, and cancel a held gesture only for a real geometry change (not an unchanged ResizeObserver notification). A local accepted-selection counter makes subsequent video actionable. Two numerical tests cover five mobile hit regions and unchanged/changed geometry. These changes address fragile code paths; the exact original runtime cause and successful phone repair remain unverified until a new device recording. The menu occlusion and segment deformation reported in the previous audit remain open.

## Follow-up: owner still cannot see the mobile specimen
The previous portal-based repair failed the owner's phone check. Remove it rather than mark it successful. The lab now renders one unconditional navigation specimen in normal document flow at every viewport. Route-scoped CSS overrides inherited fixed positioning and translation on the specimen only. On mobile it remains a five-column row; on desktop it retains the vertical layout. L42 is a visible lab marker to distinguish this revision. This deliberately tests the component inside the workbench, not the production Dock's viewport anchoring. The original cause is not established; fresh phone visibility/touch confirmation remains required.

## L43 — reduce effects and consolidate motion ownership
The owner confirmed L42 visibility and supplied phone/desktop failure recordings. Phone selected-state/lens mismatch is confirmed; the exact runtime scheduler failure is not isolated. The shared custom RAF spring wrapper is replaced by the already installed Motion engine, preserving its consumer API, release velocity and current position. Navigation also resets on blur/background if a pointer-up is lost. Chromium selection/retarget/vertical and horizontal drag were exercised; device acceptance remains open.

Remove global pointer-following radial lighting. Vertical skew is zero rather than an angle amplified by a wide row; desktop specimen width is constrained to sidebar proportions. The new optional menu has one clipped material viewport with bounds driven by one spring and unscaled foreground. This accepts layout work for a small menu instead of transforming a filtered sibling with WebKit occlusion artifacts. It is not compositor-only and no performance improvement is claimed. Chromium menu selection, Escape and interrupted closing/reopening succeeded. Actual iPhone fallback rendering and new gesture behavior require a new device recording.

## L44 — repeated taps are not drag acquisition
Pointer-down used jump(current) before detecting drag, stopping a travelling lens on every repeated tap. Tap release then supplied zero velocity. Navigation and segment now keep positional motion alive until the movement threshold is crossed, rebase from current presentation at acquisition, and retain same-target animations. This intentionally distinguishes a stationary held press from active dragging; press deformation still responds at pointer-down. Physical-device repeat/hold/reversal verification remains open.

## L45 — main application and balanced light/dark material ownership
The owner removed the physical Safari/iPhone gate for this stage. The reviewed resistance and bounded menu driver are now main-app defaults. Action menus use the same driver; trigger opacity and menu depth follow its progress without scaling labels. A dedicated dock-material sibling supplies the mobile substrate without filtering the navigation parent. Directional deformation is smaller and shear is zero.

Material colour, tint and shadows now live in material-system.css, with legacy paint/token declarations removed from seven style files. Content remains solid, ambient lighting is an independent noninteractive element and controls/transients have explicit layer roles. Light-theme primary-action text must retain accentink rather than inherit generic glass-control ink; a stale high-specificity rule was removed. Section transitions are a single brief, reduced-motion-aware content animation, not a cascade. Chromium desktop and a true narrow iframe rendering of the main app checked both themes, menus, charts, journal and the unsaved entry sheet. No hardware or timing benchmark is claimed.

## L46 — Dock correction after box-like final tab
The L45 horizontal lens used button width+12, left−6 and radius .34 of its short side, yielding a 2 px right gap in the 390 px diagnostic scene. L46 uses button centres, a capsule profile and a presentation boundary that includes directional deformation; the resting gap is 8 px and the minimum silhouette inset is 6 px. The substrate is masked out beneath the moving lens, retaining a small overlap at its rim. Both masks and position use the same presentation values.

A concrete optical bug was established through computed CSS: L45's navigation rule overrode the generic SVG selector, leaving blur(1px) even when the data attribute said svg. The L46 horizontal selector applies its actual URL filter. Chromium contrasting-line screenshots show a changed line path; forced fallback reports frosted/blur(.6px). This does not establish Safari, GPU or native material parity. No frame/layout benchmark or continuous touch recording was made. Four repeated taps committed once, two directional desktop drags completed and narrow main-app layout/scroll/keyboard checks succeeded. The detailed evidence and untested gesture paths are in RELEASE_L46.md.

### Production follow-up
Published Chromium computed none while preview computed URL. The installed Lightning CSS reproduced this when the standard declaration preceded an identical WebKit one: output retained only the unsupported prefixed property. Reversing equivalent declarations keeps both. Application CSS pairs now use prefixed-first/standard-last and verify-built-glass.mjs asserts standard SVG/substrate/fallback rules in the built artifact. Preview success alone was insufficient evidence for published optics.

## L48 — hierarchy before more optics
A transparent sticky source group allowed period text to pass under labels. It now stays in document flow, avoiding the collision without stacking fixes. Legacy sheet selectors were removed and replaced with one header/body/footer layout; desktop single-lap distance/time share a row, while mobile preserves the focus-friendly two-part input. Generic mobile 16px-important sizing explicitly excludes the time control so its 27px type survives.

The optical registry now only tags intended filtered surfaces. Triggers and vertical navigation receive matching actual-filter rules, and built-artifact checks cover segment/triggers/menus/settings. A renderer flag is still insufficient proof; production computed checks are separate. Chromium tested all five sections in both themes, three iframe widths, source dragging, entry validation/focus, theme change with an open menu, and Escape containment. No native hardware/GPU equivalence is inferred.
