import assert from 'node:assert/strict';
import {fragmentShader} from './GlassShader.ts';
const displacement=(t,bezel,thickness,ior)=>{t=Math.max(.025,Math.min(1,t));const h=t=>Math.pow(1-Math.pow(1-t,4),.25);const slope=Math.atan((h(Math.min(t+.001,1))-h(t))/.001*(thickness/bezel));const theta=Math.asin(Math.max(-1,Math.min(1,Math.sin(slope)/ior)));return Math.max(0,Math.min(16,bezel*.75,h(t)*thickness*(Math.tan(slope)-Math.tan(theta))))};
let maximum=0;
for(const thickness of [14,19,25])for(const bezel of [1,8,16,24])for(const ior of [1.01,1.46,2])for(let i=0;i<=10000;i++){const d=displacement(i/10000,bezel,thickness,ior);assert(Number.isFinite(d)&&d>=0&&d<=Math.min(16,bezel*.75));maximum=Math.max(maximum,d)}
const signedHead=(p,v)=>Math.max(-35,Math.min(35,v))*.18*Math.max(-1,Math.min(1,p));
assert.equal(signedHead(1,35),6.3);assert.equal(signedHead(-1,35),-6.3);assert.equal(signedHead(1,-35),-6.3);assert.equal(35*.25,8.75);
for(const size of [1,65,1692])for(const uv of [-2,0,.5,1,3]){const lo=.5/size,hi=1-lo,v=Math.max(lo,Math.min(hi,uv));assert(v>=lo&&v<=hi)}
assert(fragmentShader.includes('clamp(rawDisplacement, 0.0, min(16.0, bezel * 0.75))'));
assert(fragmentShader.includes('textureSize(uBgTex, 0)'));
assert(fragmentShader.includes('max(length(grad), 0.00001)'));
console.log('PASS: numeric material model, displacement max '+maximum+' CSS px; signed head/tail ±6.3px, skew ±8.75px; UV half-texel bounds. NOT a GPU render test.');
