'use client';
import {useEffect,useRef} from 'react';
import {useFrameSpring} from './useFrameSpring';
import type {MenuRect} from '../lib/menu-morph';
// Animate a bounded material viewport. Foreground glyphs never scale and no
// transformed backdrop plane extends beyond the visible menu on WebKit.
export function useMenuLayer(){
 const progress=useFrameSpring(0,{stiffness:460,damping:42});
 const job=useRef<{el:HTMLElement;source:MenuRect;target:MenuRect;open:boolean;done:()=>void;trigger?:HTMLElement}|null>(null);
 const draw=()=>{const j=job.current;if(!j)return;const p=Math.max(0,Math.min(1,progress.get())),mix=(a:number,b:number)=>a+(b-a)*p;
  const left=mix(j.source.left,j.target.left),top=mix(j.source.top,j.target.top);
  Object.assign(j.el.style,{left:left+'px',top:top+'px',width:mix(j.source.width,j.target.width)+'px',height:mix(j.source.height,j.target.height)+'px',borderRadius:mix(j.source.height/2,22)+'px',opacity:String(Math.min(1,p*4)),overflow:'hidden',transform:'none'});
  const content=j.el.querySelector<HTMLElement>('.glass-menu-options,.glass-action-items');
  if(content)Object.assign(content.style,{position:'absolute',left:(j.target.left-left+7)+'px',top:(j.target.top-top+7)+'px',width:(j.target.width-16)+'px',opacity:String(Math.max(0,Math.min(1,(p-.32)/.55))),clipPath:'none',transform:'none'});
  j.el.dataset.menuProgress=p.toFixed(3);j.el.style.setProperty('--menu-progress',String(p));if(j.trigger)j.trigger.style.opacity=String(1-Math.min(1,p*5));
  if(!j.open&&p===0){job.current=null;j.done()}
 };
 useEffect(()=>progress.on('change',draw),[progress]);
 return {start(el:HTMLElement,source:MenuRect,target:MenuRect,open:boolean,done:()=>void,trigger?:HTMLElement){const fresh=job.current?.el!==el;job.current={el,source,target,open,done,trigger};if(fresh)progress.jump(0);if(matchMedia('(prefers-reduced-motion: reduce)').matches)progress.jump(open?1:0);else progress.set(open?1:0);draw()},stop(){if(job.current?.trigger)job.current.trigger.style.removeProperty('opacity');job.current=null;progress.jump(0)}};
}
