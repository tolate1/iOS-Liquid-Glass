'use client';
import {useEffect,useMemo,useRef} from 'react';
import {animate,useMotionValue,type AnimationPlaybackControls} from 'motion/react';
import type {SpringOptions} from '../research/liquid-glass/GlassPhysics';
// One Motion driver owns presentation and scheduling, including tab visibility changes.
export function useFrameSpring(initial:number,options:SpringOptions={}){
 const value=useMotionValue(initial),animation=useRef<AnimationPlaybackControls|null>(null),target=useRef(initial),config=useRef(options);
 useEffect(()=>()=>{animation.current?.stop()},[]);
 return useMemo(()=>{
  const run=(n:number,velocity?:number)=>{if(target.current===n&&(velocity===undefined||animation.current?.state==='running'))return;target.current=n;animation.current?.stop();animation.current=animate(value,n,{type:'spring',stiffness:config.current.stiffness??210,damping:config.current.damping??21,mass:config.current.mass??1,...(velocity===undefined?{}:{velocity:Math.max(-1000,Math.min(1000,velocity))}),restDelta:.01,restSpeed:.05})};
  return {value,get:()=>value.get(),getVelocity:()=>value.getVelocity(),on:value.on.bind(value),set:(n:number)=>run(n),release:(n:number,v:number)=>run(n,v),jump:(n:number)=>{animation.current?.stop();animation.current=null;target.current=n;value.jump(n)}};
 },[value]);
}
