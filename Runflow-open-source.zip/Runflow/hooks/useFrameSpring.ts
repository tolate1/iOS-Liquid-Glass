'use client';
import {useEffect,useMemo,useRef} from 'react';
import {useMotionValue} from 'motion/react';
import {SpringValue,type SpringOptions} from '../research/liquid-glass/GlassPhysics';
// Sleep at equilibrium; retargeting wakes the same model without resetting velocity.
export function useFrameSpring(initial:number,options:SpringOptions={}){
 const model=useRef(new SpringValue(initial,options)),value=useMotionValue(initial);
 const clock=useRef({frame:0,last:0,active:false});
 const wake=useRef<()=>void>(()=>{});
 useEffect(()=>{
  const state=clock.current;state.active=true;
  const step=(now:number)=>{state.frame=0;const moving=model.current.step((now-state.last)/1000);state.last=now;value.set(model.current.current);if(moving&&state.active&&!state.frame)state.frame=requestAnimationFrame(step)};
  wake.current=()=>{if(!state.active||state.frame)return;state.last=performance.now();state.frame=requestAnimationFrame(step)};
  wake.current();return()=>{state.active=false;cancelAnimationFrame(state.frame);state.frame=0};
 },[value]);
 return useMemo(()=>({value,get:()=>value.get(),getVelocity:()=>model.current.velocity,on:value.on.bind(value),set:(n:number)=>{if(n===model.current.target&&model.current.velocity===0&&n===model.current.current)return;model.current.setTarget(n);wake.current()},release:(target:number,velocity:number)=>{model.current.velocity=Math.max(-1000,Math.min(1000,velocity));model.current.setTarget(target);wake.current()},jump:(n:number)=>{model.current.set(n);value.set(n)}}),[value]);
}
