'use client';
import {useTransform,type MotionValue} from 'motion/react';
import {lensShape,type LensCornerStyle} from '../lib/lens-shape';
export function useLensShape(w:MotionValue<number>,h:MotionValue<number>,drive:MotionValue<number>,press:MotionValue<number>,axis:MotionValue<number>,cornerStyle:LensCornerStyle='capsule'){
 const shape=useTransform(()=>lensShape(w.get(),h.get(),drive.get(),press.get(),axis.get()===1,cornerStyle));
 return {width:useTransform(shape,s=>s.width),height:useTransform(shape,s=>s.height),offsetX:useTransform(shape,s=>s.offsetX),offsetY:useTransform(shape,s=>s.offsetY),skewX:useTransform(shape,s=>s.skewX),skewY:useTransform(shape,s=>s.skewY),radius:useTransform(shape,s=>s.radius),scale:useTransform(shape,s=>s.scale),angle:useTransform(shape,s=>s.lightAngle+'deg'),lightX:useTransform(shape,s=>s.lightX+'%'),lightY:useTransform(shape,s=>s.lightY+'%')};
}
