'use client';
import {useEffect,type RefObject} from 'react';
import type {MotionValue} from 'motion/react';
// Share the spring's actual presentation, including its release/settling phase.
export function useGlassMotion(ref:RefObject<HTMLElement|null>,drive:MotionValue<number>,press:MotionValue<number>){
 useEffect(()=>{const update=()=>{const el=ref.current;if(el)el.dispatchEvent(new CustomEvent('runflow:glass-motion',{bubbles:true,detail:{drive:drive.get(),press:press.get()}}))};const a=drive.on('change',update),b=press.on('change',update);update();return()=>{a();b()}},[ref,drive,press]);
}
