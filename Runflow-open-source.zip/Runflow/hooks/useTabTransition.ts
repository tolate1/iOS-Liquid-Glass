'use client';
import {startTransition,useLayoutEffect,useRef} from 'react';

// Tab changes should not fade/remount the whole content plane. The navigation
// lens already provides the continuous motion cue; pages switch immediately.
// Keep per-tab scroll positions so switching does not jump to a stale offset.
export function useTabTransition(tab:string,setTab:(tab:string)=>void){
 const content=useRef<HTMLDivElement>(null),positions=useRef<Record<string,number>>({});
 const first=useRef(true);
 useLayoutEffect(()=>{
  if(first.current){first.current=false;return}
  window.scrollTo({top:positions.current[tab]??0,behavior:'instant'});
 },[tab]);
 function navigate(next:string){
  if(next===tab)return;
  positions.current[tab]=window.scrollY;
  // Defer chart-heavy content rendering; the persistent lens responds immediately.
  // Unlike flushSync, this update remains interruptible on slower iPhones.
  startTransition(()=>setTab(next));
 }
 return {content,navigate};
}
