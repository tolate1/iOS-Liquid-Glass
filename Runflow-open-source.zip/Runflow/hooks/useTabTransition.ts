'use client';
import {startTransition,useLayoutEffect,useRef} from 'react';
// Only the content plane moves; persistent navigation and commands stay mounted.
export function useTabTransition(tab:string,setTab:(tab:string)=>void){
 const content=useRef<HTMLDivElement>(null),positions=useRef<Record<string,number>>({}),first=useRef(true),animation=useRef<Animation|null>(null);
 useLayoutEffect(()=>{if(first.current){first.current=false;return}animation.current?.cancel();window.scrollTo({top:positions.current[tab]??0,behavior:'instant'});if(!matchMedia('(prefers-reduced-motion: reduce)').matches&&content.current)animation.current=content.current.animate([{opacity:.8,transform:'translateY(4px)'},{opacity:1,transform:'translateY(0)'}],{duration:140,easing:'cubic-bezier(.2,.7,.3,1)'});return()=>animation.current?.cancel()},[tab]);
 function navigate(next:string){if(next===tab)return;positions.current[tab]=window.scrollY;startTransition(()=>setTab(next))}
 return {content,navigate};
}
