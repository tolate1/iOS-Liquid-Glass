import {test} from 'node:test';
import assert from 'node:assert/strict';
import {dockAnchor,dockPresentation,DOCK_SAFE_INSET} from '../lib/dock-geometry.ts';
import {lensShape} from '../lib/lens-shape.ts';
test('first, middle and last lenses stay inside Dock throughout deformation and overshoot',()=>{
 for(const width of [300,350,370,500])for(const [padding,buttonH] of [[8,70],[6,64]]){
  const root={width,height:buttonH+padding*2},buttonW=(width-padding*2-12)/5;
  for(const index of [0,2,4]){
   const b={left:padding+index*(buttonW+3),top:padding,width:buttonW,height:buttonH},a=dockAnchor(b,root,true);
   assert.ok(Math.abs(a.x-(b.left+b.width/2))<1e-9);assert.equal(a.y,root.height/2);
   for(const d of [-18,0,18])for(const p of [0,1])for(const overshoot of [-100,0,100]){
    const shape=lensShape(a.width,a.height,d,p,true,'dock');
    const rect=dockPresentation(a.x-a.width/2+shape.offsetX+overshoot,a.y-a.height/2+shape.offsetY,shape.width,shape.height,root);
    assert.ok(rect.left>=DOCK_SAFE_INSET&&rect.left+rect.width<=width-DOCK_SAFE_INSET+.001);
    assert.ok(rect.top>=DOCK_SAFE_INSET&&rect.top+rect.height<=root.height-DOCK_SAFE_INSET+.001);
    assert.equal(shape.scale,1);assert.equal(shape.skewX,0);
   }
  }
 }
});
test('Dock resting shape is a capsule and reverses directional shape without a jump in size',()=>{
 const idle=lensShape(70,70,0,0,true,'dock');assert.equal(idle.radius,'35px 35px 35px 35px');
 const l=lensShape(70,70,-12,1,true,'dock'),r=lensShape(70,70,12,1,true,'dock');
 assert.equal(l.width,r.width);assert.equal(l.height,r.height);
 assert.equal(l.offsetX+r.offsetX,-(l.width-70));
 assert.notEqual(l.radius,r.radius);
});
