import {test} from 'node:test';
import assert from 'node:assert/strict';
import {navigationHit,sameNavigationGeometry} from '../lib/navigation-hit.ts';
test('mobile touch bounds choose all five tabs despite captured event target',()=>{
 const tabs=Array.from({length:5},(_,i)=>({value:String(i),left:12+i*70,right:80+i*70,top:700,bottom:758}));
 tabs.forEach((t,i)=>assert.equal(navigationHit(t.left+20,730,tabs),String(i)));
 assert.equal(navigationHit(20,650,tabs),undefined);
});
test('resize notifications with unchanged layout do not cancel a held gesture',()=>{
 assert.equal(sameNavigationGeometry([390,70,6,6],[390,70,6,6]),true);
 assert.equal(sameNavigationGeometry([390,70,6,6],[390,70,6.2,6]),true);
 assert.equal(sameNavigationGeometry([390,70,6,6],[844,70,6,6]),false);
});
