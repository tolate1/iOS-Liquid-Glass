import assert from 'node:assert/strict';
import test from 'node:test';
import {segmentPresentation} from '../lib/segment-geometry.ts';
test('unequal segment widths remain inside track for all pointer positions',()=>{const items=[{left:4,width:140},{left:146,width:80}];for(let c=-200;c<500;c++){const p=segmentPresentation(items,c);assert.ok(p.left>=4);assert.ok(p.left+p.width<=226);assert.ok(p.width>=80&&p.width<=140)}assert.deepEqual(segmentPresentation(items,74),{left:4,width:140});assert.deepEqual(segmentPresentation(items,186),{left:146,width:80})});
test('reversal is continuous and single segment is stable',()=>{const items=[{left:4,width:140},{left:146,width:80}];for(let c=75;c<186;c++){const a=segmentPresentation(items,c),b=segmentPresentation(items,c-.01);assert.ok(Math.abs(a.left-b.left)<.1);assert.ok(Math.abs(a.width-b.width)<.1)}assert.deepEqual(segmentPresentation([{left:4,width:80}],900),{left:4,width:80})});
