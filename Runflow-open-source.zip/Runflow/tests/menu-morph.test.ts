import test from 'node:test';
import assert from 'node:assert/strict';
import {menuMorph} from '../lib/menu-morph.ts';
import {SpringValue} from '../research/liquid-glass/GlassPhysics.ts';
import {sampleVelocity,releaseVelocity} from '../lib/gesture-sampling.ts';
const source={left:150,top:20,width:100,height:44},target={left:60,top:72,width:190,height:150};
test('material endpoints and unscaled foreground reveal are finite and bounded',()=>{assert.equal(menuMorph(1,source,target).sx,1);assert.equal(menuMorph(1,source,target).sy,1);assert.equal(menuMorph(0,source,target).opacity,0);for(let p=-.1;p<1.2;p+=.01){const f=menuMorph(p,source,target);for(const n of Object.values(f))assert.ok(Number.isFinite(n));assert.ok(f.opacity>=0&&f.opacity<=1);assert.ok(f.sx>0&&f.sy>0)}});
test('retargeting a moving progress spring preserves presentation and settles',()=>{const spring=new SpringValue(0,{stiffness:390,damping:40});spring.setTarget(1);for(let i=0;i<7;i++)spring.step(1/60);const before=menuMorph(spring.current,source,target);spring.setTarget(0);assert.deepEqual(menuMorph(spring.current,source,target),before);for(let i=0;i<240;i++)spring.step(1/60);assert.equal(spring.current,0);assert.equal(menuMorph(spring.current,source,target).opacity,0)});
test('stale hold velocity, cancel and reduced-motion release are suppressed',()=>{assert.equal(releaseVelocity(900,0,150,false,false),0);assert.equal(releaseVelocity(900,0,20,true,false),0);assert.equal(releaseVelocity(900,0,20,false,true),0);assert.equal(releaseVelocity(-900,0,20,false,false),-900);assert.equal(sampleVelocity(10,0,2000,0),5);assert.equal(sampleVelocity(100,0,1,0),1000)});
