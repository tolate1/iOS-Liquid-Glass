import {test} from 'node:test';
import assert from 'node:assert/strict';
import {lensShape} from '../lib/lens-shape.ts';
test('vertical selection remains level across sidebar and oversized workbench widths',()=>{
 for(const w of [170,270,700])for(const drive of [-18,-9,0,9,18]){
  const s=lensShape(w,54,drive,1,false,'rounded');
  assert.equal(s.skewY,0);
  assert.ok(s.height<85&&s.width<=w+9);
 }
});
test('release restores original geometry without leaving a held lens',()=>{
 const s=lensShape(70,52,0,0,true,'rounded');
 assert.equal(s.width,70);assert.equal(s.height,52);assert.equal(s.scale,1);assert.equal(s.offsetX,0);assert.equal(s.offsetY,0);
});
