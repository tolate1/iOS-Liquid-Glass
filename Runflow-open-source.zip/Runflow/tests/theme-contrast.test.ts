import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const css=readFileSync(new URL('../app/material-system.css',import.meta.url),'utf8');
const lum=(hex:string)=>{let h=hex.replace('#','');if(h.length===3)h=h.split('').map(c=>c+c).join('');const v=[0,2,4].map(i=>parseInt(h.slice(i,i+2),16)/255).map(n=>n<=.04045?n/12.92:((n+.055)/1.055)**2.4);return v[0]*.2126+v[1]*.7152+v[2]*.0722};
for(const [name,re]of [['light',/:root\{([^}]+)\}/],['dark',/html\[data-theme=dark\]\{([^}]+)\}/]] as const){
 test(`${name}: primary and secondary text retain readable contrast`,()=>{const block=css.match(re)![1];const get=(name:string)=>block.match(new RegExp('--'+name+':(#[a-fA-F0-9]+)'))![1];for(const [fg,bg]of [['ink','bg'],['ink','field'],['muted','bg'],['muted','field'],['ink','surface'],['muted','surface'],['muted','surface2'],['accentink','accent']]){const a=lum(get(fg)),b=lum(get(bg));assert.ok((Math.max(a,b)+.05)/(Math.min(a,b)+.05)>=4.5,`${fg}/${bg}`)}});
}
