import test from 'node:test';
import assert from 'node:assert/strict';
import {ALL_GLASS_LAYERS,SCENE_PROFILES,composeAdaptiveGlass,type GlassScene} from '../lib/adaptive-glass-engine.ts';

for (const scene of Object.keys(SCENE_PROFILES) as GlassScene[]) {
  test(`Five material layers respond together on ${scene}`,()=>{
    const inputs = {scene, layers:{...ALL_GLASS_LAYERS}, touchX:.4,touchY:.6, expanded:false};
    const before = composeAdaptiveGlass({...inputs,width:58,height:46,press:0,velocity:0});
    const after = composeAdaptiveGlass({...inputs,width:238,height:217,press:1,velocity:390,expanded:true});
    assert.ok(after.animation.scaleX>before.animation.scaleX);
    assert.ok(after.mask.radius>before.mask.radius);
    assert.ok(after.glass.strength>before.glass.strength);
    assert.ok(after.light.intensity>before.light.intensity);
    assert.ok(after.shadow.intensity>before.shadow.intensity);
    assert.equal(after.environment,SCENE_PROFILES[scene].label);
  });
  test(`Individual layer toggles do not leak into other layers: ${scene}`,()=>{
    const inputs = {scene,layers:{...ALL_GLASS_LAYERS},touchX:.45,touchY:.6,
      width:238,height:217,press:.75,velocity:400,expanded:true};
    const full = composeAdaptiveGlass(inputs);
    assert.ok(full.glass.strength>0);
    const noGlass = composeAdaptiveGlass({...inputs,layers:{...inputs.layers,glass:false}});
    assert.equal(noGlass.glass.strength,0);
    assert.equal(noGlass.light.intensity,full.light.intensity);
    const noLight = composeAdaptiveGlass({...inputs,layers:{...inputs.layers,light:false}});
    assert.equal(noLight.light.intensity,0);
    assert.equal(noLight.glass.strength,full.glass.strength);
  });
}

test('Accessibility preferences disable optics and all outputs stay bounded',()=>{
  const frame=composeAdaptiveGlass({scene:'text',layers:{...ALL_GLASS_LAYERS},
    width:238,height:217,press:2,velocity:Infinity,touchX:Infinity,touchY:-10,
    expanded:true,reducedTransparency:true});
  assert.equal(frame.glass.strength,0);
  assert.ok(frame.animation.scaleX >=1 && frame.animation.scaleX<1.2);
  assert.ok(frame.light.x>=0 && frame.light.x<=100);
  assert.ok(frame.light.y>=0 && frame.light.y<=100);
  const noMotion=composeAdaptiveGlass({scene:'text',layers:{...ALL_GLASS_LAYERS},
    width:238,height:217,press:0,velocity:600,touchX:.3,touchY:.3,expanded:true,reducedMotion:true});
  assert.equal(noMotion.animation.scaleX,1);
  assert.equal(noMotion.animation.scaleY,1);
  assert.equal(noMotion.animation.tilt,0);
});
