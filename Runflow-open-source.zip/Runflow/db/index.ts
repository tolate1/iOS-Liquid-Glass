import { env } from "cloudflare:workers";
import { drizzle } from "drizzle-orm/d1";
import * as schema from "./schema";

export function getDb() {
  if (!env.DB) {
    throw new Error(
      "Database binding DB is unavailable. Initialize the local database before using the API."
    );
  }

  return drizzle(env.DB, { schema });
}
