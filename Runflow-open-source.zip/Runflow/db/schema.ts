import { sqliteTable, text } from 'drizzle-orm/sqlite-core';
export const workouts = sqliteTable('workouts', { id:text('id').primaryKey(), data:text('data').notNull() });
export const settings=sqliteTable('settings',{id:text('id').primaryKey(),data:text('data').notNull()});
