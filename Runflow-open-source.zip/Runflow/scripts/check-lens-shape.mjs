import assert from 'node:assert/strict';
import {lensShape} from '../lib/lens-shape.ts';
import {SpringValue} from '../research/liquid-glass/GlassPhysics.ts';
for(const horizontal of [true,false])for(const [w,h]of [[68,70],[170,48],[110,46]]){
 const rest=lensShape(w,h,0,0,horizontal),a=lensShape(w,h,18,1,horizontal),b=lensShape(w,h,-18,1,horizontal);
 assert.equal(rest.width,w);assert.equal(rest.height,h);assert.equal(rest.scale,1);
 assert.equal(a.width,b.width);assert.equal(a.height,b.height);
 assert.notEqual(a.radius,b.radius,'direction must change leading/trailing corners');
 assert.ok(Math.abs((horizontal?a.offsetX-b.offsetX:a.offsetY-b.offsetY))>6,'visible signed displacement');
 assert.equal(a.lightAngle+b.lightAngle,270);
 const rounded=lensShape(w,h,0,0,horizontal,'rounded');
 assert.equal(rounded.width,w);assert.equal(rounded.height,h);
 const corner=parseFloat(rounded.radius);
 assert.ok(corner<Math.min(w,h)*.4,'rounded tabs have smaller corners than a circle');
 for(const d of [-1e6,0,1e6]){const s=lensShape(w,h,d,1,horizontal);for(const key of ['width','height','offsetX','offsetY','skewX','skewY','scale'])assert.ok(Number.isFinite(s[key]));assert.ok(s.width>0&&s.height>0)}
}
const s=new SpringValue(60,{stiffness:220,damping:25,mass:1.1});s.velocity=800;s.setTarget(120);assert.ok(s.step(1/60));assert.ok(s.current>60);s.setTarget(0);let moving=true,steps=0;while(moving&&steps++<600)moving=s.step(1/60);assert.ok(!moving,'spring must sleep after reversal');assert.equal(s.current,0);assert.equal(s.velocity,0);
console.log('PASS: directional corners and offsets, pressure, bounded geometry, signed light, velocity release, reversal and settling. Not a visual test.');
