import assert from 'node:assert/strict';
import {glassDisplacement as displacement} from '../lib/glass-optics.ts';
assert(displacement(0,0,90,66).every(value=>value===0));
assert.deepEqual(displacement(100,100,90,66),[0,0]);
for(const [w,h] of [[65,58],[89,66],[110,64],[174,46]])for(let x=0;x<w/2;x+=3)for(let y=0;y<h/2;y+=3){const a=displacement(x,y,w,h),b=displacement(-x,-y,w,h);assert(a.every(Number.isFinite));assert(Math.abs(a[0]+b[0])<1e-9);assert(Math.abs(a[1]+b[1])<1e-9);assert(Math.abs(a[0])<22&&Math.abs(a[1])<22)}
assert(Math.abs(displacement(42,0,90,66)[0])>Math.abs(displacement(10,0,90,66)[0]));
console.log('PASS: bounded/finite refraction, symmetry, neutral exterior and stronger edge refraction across resting/stretched geometries.');
