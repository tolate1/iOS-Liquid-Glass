import {readFileSync,readdirSync} from 'node:fs';
import assert from 'node:assert/strict';
const folder='dist/client/_next/static/css';
const css=readdirSync(folder).filter(f=>f.endsWith('.css')).map(f=>readFileSync(folder+'/'+f,'utf8')).join('\n');
const rules=[...css.matchAll(/([^{}]+)\{([^{}]*)\}/g)];
const hasStandard=(selector,value)=>rules.some(([,s,body])=>s.includes(selector)&&new RegExp('(?:^|;)backdrop-filter:'+value+'(?:;|$)').test(body));
assert.ok(hasStandard('.glass-lens-surface[data-rf-glass=svg]','var\\(--rf-backdrop\\)'), 'Built SVG lens lost its standard backdrop-filter');
assert.ok(hasStandard('.dock-material[data-rf-glass=svg]','var\\(--rf-backdrop\\)'), 'Built shared Dock lost its standard backdrop-filter');
assert.ok(hasStandard('[data-dock-axis=horizontal] .glass-lens-surface','none'), 'Selection must not acquire a second optical filter');
console.log('Production CSS retains standard SVG, substrate and fallback backdrop filters.');

for(const selector of ['.segment-lens','.glass-select-trigger[data-rf-glass=svg]','.glass-action-trigger[data-rf-glass=svg]','.glass-menu-layer[data-rf-glass=svg]','.glass-action-menu[data-rf-glass=svg]','.glass-settings[data-rf-glass=svg]']){
 assert.ok(hasStandard(selector,'var\\(--rf-backdrop\\)'),`Built optical rule lost standard filter: ${selector}`);
}
console.log('Segment, triggers, menus and appearance retain their optical rules.');
