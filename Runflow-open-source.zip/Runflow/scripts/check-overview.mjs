import assert from 'node:assert/strict';
import {readFile,mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import ts from 'typescript';
const dir=await mkdtemp(join(tmpdir(),'runflow-overview-'));
try{
 for(const name of ['running-metrics','overview','workout-stats']){
  const source=await readFile(new URL(`../lib/${name}.ts`,import.meta.url),'utf8');
  const code=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText.replace("'./running-metrics'","'./running-metrics.mjs'");
  await writeFile(join(dir,name+'.mjs'),code);
 }
 const {runningWeek,assessmentReason}=await import(pathToFileURL(join(dir,'overview.mjs')));
 const run=(date,d,t)=>({id:date,date,title:date,laps:[{d,t},{d,t}]});
 assert.equal(runningWeek([]),null);assert.equal(runningWeek([run('2026-11-10',0,10)]),null);
 const week=runningWeek([run('2026-11-10',1,300),run('2026-11-04',1,600),run('2026-11-03',1,600),run('2026-10-28',1,600),run('2026-10-27',8,600)]);
 assert.equal(week.start,'2026-11-04');assert.equal(week.now.count,2);assert.equal(week.before.count,2);
 assert.equal(week.now.speed,8);assert.equal(week.before.speed,6);assert.equal(week.cvDelta,0);
 assert.ok(Math.abs(week.speedDelta-100/3)<1e-9);assert.equal(week.volumeDelta,0);
 assert.deepEqual(week.frequency,[1,0,0,0,0,0,1]);
 const missing=runningWeek([run('2026-11-10',1,300)]);assert.equal(missing.speedDelta,null);assert.equal(missing.volumeDelta,null);
 assert.match(assessmentReason(2.9,-25),/меньшая дистанция/);
 assert.match(assessmentReason(-20,2),/снижение стабильной скорости/);
 assert.match(assessmentReason(0,0),/не изменились/);
 const {stats,assessWorkout}=await import(pathToFileURL(join(dir,'workout-stats.mjs')));
 const fixture={id:'x',date:'2026-11-10',title:'',notes:'',laps:[{d:1,t:360},{d:1,t:3600/11},{d:1,t:180}]};
 assert.equal(stats(fixture).spread,1);assert.equal(stats(fixture).stable,10);
 assert.equal(assessWorkout(fixture,fixture).score,100);
 console.log('overview checks passed: calendar boundaries, weighted speed, missing baseline, CV and verdict');
}finally{await rm(dir,{recursive:true,force:true})}
