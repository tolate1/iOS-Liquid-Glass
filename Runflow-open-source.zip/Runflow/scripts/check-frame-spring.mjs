import assert from 'node:assert/strict';
import {SpringValue} from '../research/liquid-glass/GlassPhysics.ts';
const spring=new SpringValue(0,{stiffness:220,damping:25,mass:1.1});
spring.setTarget(122);const positions=[];
for(let i=0;i<90;i++){spring.step(1/60);positions.push(spring.current)}
assert.ok(positions.filter(p=>p>1&&p<121).length>10,'transition needs intermediate positions');
assert.ok(Math.abs(spring.current-122)<.01);
spring.set(80);spring.setTarget(10);spring.step(.016);assert.ok(spring.current<80&&spring.current>10);
spring.step(1);assert.ok(spring.current>10,'a stalled frame must not skip directly to target');
for(let i=0;i<100;i++)spring.step(.016);assert.ok(Math.abs(spring.current-10)<.01);
console.log('PASS: intermediate positions, drag release, reversal and bounded catch-up after stalled frame. Not a visual smoothness test.');
