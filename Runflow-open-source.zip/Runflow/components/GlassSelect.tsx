'use client';
import {useEffect,useId,useLayoutEffect,useRef,useState} from 'react';
import {createPortal} from 'react-dom';
import {animateGlassMenu} from '../lib/animate-glass-menu';
import {ChevronDown,Check} from 'lucide-react';
export default function GlassSelect({value,onChange,options,label}:{value:string;onChange:(v:string)=>void;options:string[];label:string}){
 const anchor=useRef<HTMLButtonElement>(null),menu=useRef<HTMLDivElement>(null),animation=useRef<Animation|null>(null),opening=useRef(false),id=useId();
 const [open,setOpen]=useState(false),[present,setPresent]=useState(false);
 function show(){opening.current=true;setPresent(true);setOpen(true)}
 useLayoutEffect(()=>{
  const panel=menu.current,button=anchor.current;if(!present||!panel||!button)return;
  const previous=animation.current;
  const r=button.getBoundingClientRect(),width=Math.min(innerWidth-20,Math.max(190,r.width));
  panel.style.width=width+'px';panel.style.maxHeight=Math.max(60,innerHeight-20)+'px';
  const content=panel.firstElementChild as HTMLElement|null;if(content)content.style.width=Math.max(0,width-16)+'px';
  const height=Math.min(innerHeight-20,(content?.scrollHeight??panel.scrollHeight)+16),left=Math.max(10,Math.min(innerWidth-width-10,r.right-width));
  const below=innerHeight-r.bottom>=Math.min(height+10,210)||r.top<height+20;
  const top=Math.max(10,Math.min(innerHeight-height-10,below?r.bottom+8:r.top-height-8));
  panel.style.left=left+'px';panel.style.top=top+'px';
  panel.dataset.expanded=String(open);
  animation.current=animateGlassMenu(panel,button,open,width,height,left,top,previous,()=>{if(!open){animation.current=null;setPresent(false)}});
  if(open&&opening.current){opening.current=false;panel.querySelector<HTMLElement>('[aria-selected=true]')?.focus()}
 },[open,present]);
 useEffect(()=>()=>animation.current?.cancel(),[]);
 useEffect(()=>{if(!open)return;const close=(e:PointerEvent)=>{if(!anchor.current?.contains(e.target as Node)&&!menu.current?.contains(e.target as Node))setOpen(false)},scroll=(e:Event)=>{if(!menu.current?.contains(e.target as Node))setOpen(false)};document.addEventListener('pointerdown',close);window.addEventListener('resize',scroll);window.addEventListener('scroll',scroll,true);return()=>{document.removeEventListener('pointerdown',close);window.removeEventListener('resize',scroll);window.removeEventListener('scroll',scroll,true)}},[open]);
 return <><button ref={anchor} type="button" className="glass-select-trigger" aria-label={label} aria-haspopup="listbox" aria-expanded={open} aria-controls={present?id:undefined} onClick={()=>open?setOpen(false):show()} onKeyDown={e=>{if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();show()}}}>{value}<ChevronDown size={14}/></button>{present&&createPortal(<div id={id} ref={menu} className="glass-menu-layer" role="listbox" aria-label={label} aria-hidden={!open} inert={!open} style={{transformOrigin:'top left',pointerEvents:open?'auto':'none'}} onKeyDown={e=>{if(e.key==='Escape'){e.preventDefault();setOpen(false);anchor.current?.focus()}if(e.key==='Tab'){setOpen(false);anchor.current?.focus()}if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();const all=Array.from(menu.current!.querySelectorAll<HTMLElement>('[role=option]')),i=all.indexOf(document.activeElement as HTMLElement);all[e.key==='Home'?0:e.key==='End'?all.length-1:(i+(e.key==='ArrowDown'?1:-1)+all.length)%all.length]?.focus()}}}><div className="glass-menu-options">{options.map(v=><button role="option" aria-selected={value===v} tabIndex={-1} key={v} onClick={()=>{onChange(v);setOpen(false);anchor.current?.focus()}}>{v}{value===v&&<Check size={15}/>}</button>)}</div></div>,document.body)}</>
}
