'use client';
import {useEffect} from 'react';
// Crossfade only the data viewport on a deliberate metric/scale change.
// Do not morph values with different units or replay a page entrance.
export default function ChartMotion({revision}:{revision:string}){
 useEffect(()=>{if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;const nodes=Array.from(document.querySelectorAll<SVGElement>('.chartgrid .recharts-surface,.compare .recharts-surface'));const animations=nodes.map(el=>el.animate([{opacity:.72},{opacity:1}],{duration:180,easing:'ease-out'}));return()=>animations.forEach(a=>a.cancel())},[revision]);return null;
}
