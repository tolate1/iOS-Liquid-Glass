'use client';

import {useEffect,useId,useRef,useState,type KeyboardEvent} from 'react';
import {ArrowUpRight,Check,ChartNoAxesCombined,Footprints,MoreHorizontal,Settings2,X} from 'lucide-react';
import {AdaptiveGlassController} from '../lib/AdaptiveGlassController';
import {ALL_GLASS_LAYERS,SCENE_PROFILES,type GlassLayer,type GlassLayers,type GlassScene} from '../lib/adaptive-glass-engine';

const SCENES: GlassScene[] = ['dark','light','color','text'];
const LAYERS: {id:GlassLayer;label:string;info:string}[] = [
  {id:'animation',label:'Анимация',info:'Упругость, скорость, форма'},
  {id:'mask',label:'Маска',info:'Радиусы и контур линзы'},
  {id:'glass',label:'Стекло',info:'Оптический путь и плотность'},
  {id:'light',label:'Свет',info:'Краевые блики и касание'},
  {id:'shadow',label:'Тень',info:'Глубина и высота'},
];

function CalibrationScene({scene}:{scene:GlassScene}) {
  return <div className="age-calibration" aria-hidden="true">
    <div className="age-grid"/>
    <div className="age-glow-a"/><div className="age-glow-b"/>
    <div className="age-calibration-copy"><span>RUNFLOW</span><strong>04:36 <small>/ км</small></strong><span>Участок · 1,20 км</span></div>
    <div className="age-dense-copy"><span>01</span> ТЕМП · СРЕДНИЙ <span>02</span> ДИСТАНЦИЯ</div>
    <svg className="age-chart" viewBox="0 0 310 105" preserveAspectRatio="none" role="presentation"><path d="M0 80 L40 59 L77 75 L115 19 L157 49 L190 30 L232 68 L270 20 L310 46" fill="none" stroke="currentColor" strokeWidth="2.5"/><path d="M0 91 H310 M0 51 H310 M0 11 H310" fill="none" stroke="currentColor" strokeOpacity=".25" strokeWidth="1"/></svg>
    {scene==='text'&&<div className="age-paragraph">Километры — 05:11 · Ритм — 162 · Круг 04:36 · Данные на фоне должны оставаться читаемыми.</div>}
  </div>;
}

function GlassSceneCard({scene,layers}:{scene:GlassScene;layers:GlassLayers}) {
  const id=useId();
  const shellRef=useRef<HTMLDivElement>(null),materialRef=useRef<HTMLDivElement>(null);
  const triggerRef=useRef<HTMLButtonElement>(null);
  const engine=useRef<AdaptiveGlassController|null>(null);
  const [open,setOpen]=useState(false),[selection,setSelection]=useState('');
  useEffect(()=>{
    if(!shellRef.current||!materialRef.current)return;
    const value=new AdaptiveGlassController(shellRef.current,materialRef.current,scene);
    engine.current=value;
    value.setLayers(layers);value.setExpanded(open);
    return()=>{engine.current=null;value.dispose()};
    // All subsequent layer/open updates go through the same persistent controller.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[scene]);
  useEffect(()=>{engine.current?.setLayers(layers)},[layers]);
  useEffect(()=>{engine.current?.setExpanded(open)},[open]);
  useEffect(()=>{
    if(!open)return;
    const down=(e:PointerEvent)=>{
      if(shellRef.current&&!shellRef.current.contains(e.target as Node))setOpen(false);
    };
    document.addEventListener('pointerdown',down);
    return()=>document.removeEventListener('pointerdown',down);
  },[open]);
  function handleKey(e:KeyboardEvent<HTMLDivElement>){
    if(!open)return;
    if(e.key==='Escape'){e.preventDefault();setOpen(false);triggerRef.current?.focus();return}
    if(!['ArrowDown','ArrowUp','Home','End'].includes(e.key))return;
    e.preventDefault();
    const items=Array.from(shellRef.current?.querySelectorAll<HTMLButtonElement>('[role="menuitem"]')??[]);
    if(!items.length)return;
    const i=items.indexOf(document.activeElement as HTMLButtonElement);
    const next=e.key==='Home'?0:e.key==='End'?items.length-1:
      (i+(e.key==='ArrowDown'?1:-1)+items.length)%items.length;
    items[next]?.focus();
  }
  function choose(label:string){setSelection(label);setOpen(false);triggerRef.current?.focus()}
  return <article className={`age-card age-${scene}`}>
    <div className="age-card-heading"><strong>{SCENE_PROFILES[scene].label}</strong><small>Яркость {SCENE_PROFILES[scene].luminance.toFixed(2)} · Контраст {SCENE_PROFILES[scene].contrast.toFixed(2)}</small></div>
    <div className="age-stage" data-age-scene={scene}>
      <CalibrationScene scene={scene}/>
      <div className="age-shell" ref={shellRef} onKeyDown={handleKey}>
        <div className="age-material" ref={materialRef} aria-hidden="true"/>
        <div className="age-content">
          <button type="button" ref={triggerRef} className="age-trigger" aria-label={open?'Закрыть стеклянное меню':'Открыть стеклянное меню'} aria-expanded={open} aria-controls={open?id:undefined} aria-haspopup="menu"
            onKeyDown={e=>{if(e.key==='Enter'||e.key===' ')engine.current?.pulseKeyboard();if(e.key==='ArrowDown'&&!open){e.preventDefault();setOpen(true);requestAnimationFrame(()=>shellRef.current?.querySelector<HTMLButtonElement>('[role=menuitem]')?.focus())}}}
            onClick={()=>setOpen(v=>!v)}>
            <span>{open?'Действия':'Меню'}</span>{open?<X size={17}/>:<MoreHorizontal size={19}/>}
          </button>
          {open&&<div className="age-menu" id={id} role="menu" aria-label={`Действия: ${SCENE_PROFILES[scene].label}`}>
            <button role="menuitem" type="button" onClick={()=>choose('Новая пробежка')}><Footprints size={17}/>Новая пробежка<ArrowUpRight size={14}/></button>
            <button role="menuitem" type="button" onClick={()=>choose('Прогресс')}><ChartNoAxesCombined size={17}/>Прогресс<ArrowUpRight size={14}/></button>
            <button role="menuitem" type="button" onClick={()=>choose('Настройки')}><Settings2 size={17}/>Настройки<ArrowUpRight size={14}/></button>
          </div>}
        </div>
      </div>
      <div className="age-calibration-note">Сетка и график — реальный DOM под линзой</div>
    </div>
    <p className="age-card-result" aria-live="polite">{selection?<><Check size={13}/> Тестовое действие: {selection}</>:'Нажми кнопку, посмотри раскрытие и нажми пункт'}</p>
  </article>;
}

export default function AdaptiveGlassComparison(){
  const [layers,setLayers]=useState<GlassLayers>({...ALL_GLASS_LAYERS});
  const [diagnosis,setDiagnosis]=useState('');
  const enabledCount=Object.values(layers).filter(Boolean).length;
  const toggle=(key:GlassLayer)=>setLayers(old=>({...old,[key]:!old[key]}));
  function exportReport(){
    const report={createdAt:new Date().toISOString(),artifact:'Runflow AdaptiveGlass lab v38',
      scenes:SCENES.map(scene=>({scene,...SCENE_PROFILES[scene]})),layers,
      paths:Array.from(document.querySelectorAll<HTMLElement>('.age-shell'))
        .map(el=>({scene:el.dataset.ageEnvironment,opticalPath:el.dataset.ageOpticalPath,state:el.dataset.ageState})),
      userAgent:navigator.userAgent,dpr:window.devicePixelRatio,
      reducedMotion:matchMedia('(prefers-reduced-motion: reduce)').matches,
      reducedTransparency:matchMedia('(prefers-reduced-transparency: reduce)').matches,
      highContrast:matchMedia('(prefers-contrast: more)').matches,
      caveat:'No real-device or visible refraction verification. svg-candidate indicates capability heuristics only.'};
    const url=URL.createObjectURL(new Blob([JSON.stringify(report,null,2)],{type:'application/json'}));
    const anchor=document.createElement('a');anchor.href=url;anchor.download='runflow-adaptive-glass-lab.json';anchor.click();
    window.setTimeout(()=>URL.revokeObjectURL(url),1000);
    setDiagnosis('Диагностика сохранена: статус SVG — только предположение о поддержке, не подтверждение качества.');
  }
  return <section className="age-lab" aria-labelledby="age-title">
    <div className="age-heading"><div><p className="age-kicker">RUNFLOW v38 / ADAPTIVE GLASS LAB</p><h2 id="age-title">Одна форма. Четыре окружения.</h2><p>Каждая кнопка открывает то же меню. Пять подсистем рассчитываются из одного состояния касания, раскрытия и движения, но подстройка материала зависит от фона.</p></div><button type="button" className="age-export" onClick={exportReport}>Экспорт диагностики</button></div>
    <div className="age-layer-controls" role="group" aria-label="Подсистемы материала">
      {LAYERS.map(layer=><label key={layer.id} className={'age-layer '+(layers[layer.id]?'is-active':'')} title={layer.info}><input type="checkbox" checked={layers[layer.id]} onChange={()=>toggle(layer.id)}/><span>{layer.label}</span></label>)}
      <button type="button" className="age-all" onClick={()=>setLayers(enabledCount===5?{animation:false,mask:false,glass:false,light:false,shadow:false}:{...ALL_GLASS_LAYERS})}>{enabledCount===5?'Отключить все':'Включить все'}</button>
    </div>
    <div className="age-scenes">{SCENES.map(scene=><GlassSceneCard key={scene} scene={scene} layers={layers}/>)}</div>
    <div className="age-caption"><p><strong>Порядок проверки:</strong> нажми кнопку → открой меню → выбери действие → отключай по одному слою → повтори для каждого фона. Сравни края и читаемость текста под линзой.</p><p><strong>Оптическая честность:</strong> SVG displacement — эксперимент для поддерживаемых движков, а не доказанная Apple-рефракция. Если путь недоступен, используется обычное размытие; при Reduced Transparency материал непрозрачен. Информационные карточки приложения не меняются.</p>{diagnosis&&<p role="status">{diagnosis}</p>}</div>
  </section>;
}
