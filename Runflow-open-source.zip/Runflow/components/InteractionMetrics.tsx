'use client';
import {useEffect,useRef,useState} from 'react';
export default function InteractionMetrics({variant}:{variant:string}){
 const [running,setRunning]=useState(false),[reports,setReports]=useState<string[]>([]);const revision=useRef(variant);revision.current=variant;
 useEffect(()=>{if(!running)return;const label=revision.current;let raf=0,last=0,frames:number[]=[],slow=0,forced=0;
 const supported=typeof PerformanceObserver!=='undefined'&&PerformanceObserver.supportedEntryTypes.includes('long-animation-frame');
 const observer=supported?new PerformanceObserver(list=>{for(const entry of list.getEntries()){slow++;for(const script of (entry as any).scripts??[])forced+=script.forcedStyleAndLayoutDuration??0}}):null;
 observer?.observe({type:'long-animation-frame',buffered:false});
 const tick=(now:number)=>{if(last)frames.push(now-last);last=now;if(frames.length<240){raf=requestAnimationFrame(tick);return}const sorted=[...frames].sort((a,b)=>a-b);setReports(prev=>[`${label}: p50 ${sorted[120].toFixed(1)} ms; p95 ${sorted[228].toFixed(1)} ms; >25 ms ${frames.filter(x=>x>25).length}/${frames.length}; ${supported?`slow-frame entries ${slow}; reported forced style/layout ${forced.toFixed(2)} ms`:'forced style/layout unavailable'}`,...prev].slice(0,6));setRunning(false)};
 raf=requestAnimationFrame(tick);return()=>{cancelAnimationFrame(raf);observer?.disconnect()};
 },[running]);
 return <section className="panel"><h2>Замер текущего варианта</h2><button disabled={running} onClick={()=>setRunning(true)}>{running?'Выполняй жест или открывай меню…':'Записать 240 интервалов кадров'}</button><p>Сравнивай на одном устройстве. RAF — интервалы вызовов, не GPU-время. Forced style/layout учитывается только в поддерживаемых записях медленных кадров; ноль не доказывает отсутствие layout. Во время замера не меняй вариант.</p>{reports.map((r,i)=><p key={i} style={{fontVariantNumeric:'tabular-nums'}}>{r}</p>)}</section>
}
