'use client';

import {useEffect} from 'react';

// A single listener handles touch, mouse and pen without React rerenders.
// Only small functional glass controls opt in; chart and navigation transforms
// remain owned by their existing components.
const CONTROL_SELECTOR = [
  '.app button.themebutton',
  '.app button.iconbutton',
  '.app button.glassbutton',
  '.app button.glass-select-trigger',
  '.app button.glass-action-trigger',
  '.app button.metric-help-button',
  '.app .headeractions > button.primary',
  '.app .heroactions > button',
  '.glass-menu-layer > button',
  '.glass-action-menu button',
].join(',');

export default function GlassPressFeedback(){
 useEffect(()=>{
  let active:HTMLElement|null=null;
  let pointer:number|null=null;
  const clearTimers=new Map<HTMLElement,number>();
  const target=(node:EventTarget|null)=>node instanceof Element?node.closest<HTMLElement>(CONTROL_SELECTOR):null;
  function mark(el:HTMLElement,x:number,y:number){
   const r=el.getBoundingClientRect();
   if(r.width<1||r.height<1)return;
   el.style.setProperty('--rf-touch-x',`${Math.max(8,Math.min(92,(x-r.left)/r.width*100))}%`);
   el.style.setProperty('--rf-touch-y',`${Math.max(10,Math.min(90,(y-r.top)/r.height*100))}%`);
  }
  function release(){
   if(!active)return;
   const el=active;active=null;pointer=null;
   if(!el.isConnected)return;
   el.dataset.rfPress='release';
   const prior=clearTimers.get(el);if(prior)clearTimeout(prior);
   clearTimers.set(el,window.setTimeout(()=>{clearTimers.delete(el);if(el.isConnected)delete el.dataset.rfPress},420));
  }
  function down(e:PointerEvent){
   if(e.pointerType==='mouse'&&e.button!==0)return;
   const el=target(e.target);
   if(!el||el.matches(':disabled,[aria-disabled="true"]'))return;
   release();
   const prior=clearTimers.get(el);if(prior){clearTimeout(prior);clearTimers.delete(el)}
   active=el;pointer=e.pointerId;mark(el,e.clientX,e.clientY);el.dataset.rfPress='down';
  }
  function move(e:PointerEvent){if(active&&pointer===e.pointerId)mark(active,e.clientX,e.clientY)}
  function up(e:PointerEvent){if(pointer===e.pointerId)release()}
  function keydown(e:KeyboardEvent){
   if(e.repeat||(e.key!==' '&&e.key!=='Enter'))return;
   const el=target(e.target);if(!el||el.matches(':disabled,[aria-disabled="true"]'))return;
   release();active=el;pointer=null;el.style.setProperty('--rf-touch-x','50%');el.style.setProperty('--rf-touch-y','50%');el.dataset.rfPress='down';
  }
  function keyup(e:KeyboardEvent){if(e.key===' '||e.key==='Enter')release()}
  document.addEventListener('pointerdown',down,{passive:true});
  document.addEventListener('pointermove',move,{passive:true});
  document.addEventListener('pointerup',up,{passive:true});
  document.addEventListener('pointercancel',up,{passive:true});
  document.addEventListener('keydown',keydown);
  document.addEventListener('keyup',keyup);
  window.addEventListener('blur',release);
  return()=>{
   release();for(const timer of clearTimers.values())clearTimeout(timer);
   clearTimers.clear();
   document.removeEventListener('pointerdown',down);
   document.removeEventListener('pointermove',move);
   document.removeEventListener('pointerup',up);
   document.removeEventListener('pointercancel',up);
   document.removeEventListener('keydown',keydown);
   document.removeEventListener('keyup',keyup);
   window.removeEventListener('blur',release);
  };
 },[]);
 return null;
}
