'use client';
import {useEffect,useLayoutEffect,useRef} from 'react';
import {useGlassDrag} from '../hooks/useGlassDrag';
import {useGlassMotion} from '../hooks/useGlassMotion';
import {useLensShape} from '../hooks/useLensShape';
import {useFrameSpring} from '../hooks/useFrameSpring';
import {motion,useReducedMotion,useMotionValue,useTransform,type MotionStyle} from 'motion/react';
type Option={value:string;label:string};
export default function GlassSegment({value,onChange,options,label,className=''}:{value:string;onChange:(value:string)=>void;options:Option[];label:string;className?:string}){
 const root=useRef<HTMLDivElement>(null),started=useRef(false),reduce=useReducedMotion();
 const x=useFrameSpring(0,{stiffness:330,damping:30}),width=useFrameSpring(0,{stiffness:330,damping:30});
 const baseH=useMotionValue(0),axis=useMotionValue(1),drive=useFrameSpring(0,{stiffness:240,damping:23}),press=useFrameSpring(0,{stiffness:350,damping:25});
 const drag=useGlassDrag({root,x,width,press,drive,reduce,value,options,onChange});
 const surface=useRef<HTMLDivElement>(null);useGlassMotion(surface,drive.value,press.value);
 const shape=useLensShape(width.value,baseH,drive.value,press.value,axis),renderX=useTransform(()=>x.get()+shape.offsetX.get()),opacity=useTransform(width.value,w=>w>0?1:0);
 useEffect(()=>x.on('change',()=>{if(!drag.gesture.current)drive.set(reduce?0:Math.max(-18,Math.min(18,x.getVelocity()*.02)))}),[x,drive,reduce]);
 useEffect(()=>{if(reduce){drive.jump(0);press.jump(0)}},[reduce,drive,press]);
 useLayoutEffect(()=>{const measure=()=>{drag.cancel();const el=root.current?.querySelector<HTMLElement>('button[aria-pressed="true"]');if(!el)return;baseH.set(el.offsetHeight);if(!started.current||reduce){x.jump(el.offsetLeft);width.jump(el.offsetWidth);started.current=true}x.set(el.offsetLeft);width.set(el.offsetWidth)};measure();const r=new ResizeObserver(measure);if(root.current)r.observe(root.current);return()=>r.disconnect()},[value,reduce,x,width]);
 useEffect(()=>{if(process.env.NODE_ENV!=='development')return;const samples:number[]=[];const off=x.on('change',()=>{samples.push(Number(x.get().toFixed(2)));if(samples.length>40)samples.shift();if(root.current)root.current.dataset.motionSamples=JSON.stringify(samples)});return off},[x]);
 return <div ref={root} role="group" aria-label={label} className={'liquid-segment '+className} onPointerDown={drag.onPointerDown} onPointerMove={drag.onPointerMove} onPointerUp={drag.onPointerUp} onPointerCancel={drag.onPointerCancel} onLostPointerCapture={drag.onLostPointerCapture} onClickCapture={drag.onClickCapture} onContextMenu={e=>e.preventDefault()}>{options.map((o,i)=><button key={o.value} type="button" aria-pressed={o.value===value} onClick={()=>onChange(o.value)} onKeyDown={e=>{if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();const n=(i+(e.key==='ArrowRight'?1:-1)+options.length)%options.length;onChange(options[n].value);root.current?.querySelectorAll('button')[n]?.focus()}}}>{o.label}</button>)}<motion.div ref={surface} aria-hidden="true" className="segment-lens" style={{x:renderX,y:shape.offsetY,width:shape.width,height:shape.height,top:4,borderRadius:shape.radius,skewX:shape.skewX,opacity,'--rf-light-x':shape.lightX,'--rf-light-y':shape.lightY,'--light-angle':shape.angle} as MotionStyle}/></div>
}
