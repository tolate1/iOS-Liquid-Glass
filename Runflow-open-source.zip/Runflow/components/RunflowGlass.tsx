'use client';
import {useEffect} from 'react';
import {GLASS_PROFILES,materialLevel} from '../lib/glass-materials';
import {createLiquidGlassDisplacementMap,supportsLiquidGlassSvgFilter} from './liquid-glass/displacementMap';

// The functional layer samples the actual backdrop. Content and chart pixels stay sharp.
export default function RunflowGlass(){
 useEffect(()=>{
  const ns='http://www.w3.org/2000/svg';
  const svg=document.createElementNS(ns,'svg');svg.setAttribute('aria-hidden','true');svg.setAttribute('width','0');svg.setAttribute('height','0');svg.style.position='fixed';svg.style.pointerEvents='none';document.body.appendChild(svg);
  const defs=document.createElementNS(ns,'defs');svg.appendChild(defs);
  const transparency=matchMedia('(prefers-reduced-transparency: reduce)'),contrast=matchMedia('(prefers-contrast: more)');
  const svgSupported=supportsLiquidGlassSvgFilter()&&!new URLSearchParams(location.search).has('glass-fallback');
  const enabled=()=>svgSupported&&!transparency.matches&&!contrast.matches;
  const entries=new Map<HTMLElement,{filter:SVGFilterElement|null;key:string;scale:number;drive:number;press:number}>();
  const pending=new Map<HTMLElement,number>();
  const cache=new Map<string,ReturnType<typeof createLiquidGlassDisplacementMap>>();
  let scrollFrame=0,scrollTimer=0,resizeFrame=0;
  const resizeDirty=new Set<HTMLElement>();
  let id=0,frame=0,strength=Number(localStorage.getItem('runflow-glass')??75);
  const scaleFor=(el:HTMLElement,scale:number)=>{
   el.style.setProperty('--rf-optical-strength',String(strength/100));
   const entry=entries.get(el),filter=entry?.filter;
   const energy=Math.min(1,Math.abs(entry?.drive??0)/18),contact=Math.max(0,Math.min(1,entry?.press??0));
   const gain=1+energy*.22+contact*.08;
   el.style.setProperty('--rf-motion-energy',String(energy));
   el.dataset.opticalGain=gain.toFixed(3);
   filter?.querySelector('feGaussianBlur')?.setAttribute('stdDeviation',String(GLASS_PROFILES[materialLevel(el)].preblur+energy*.18));
   filter?.querySelectorAll('feDisplacementMap').forEach(node=>node.setAttribute('scale',String(Math.min(GLASS_PROFILES[materialLevel(el)].maxScale,scale)*gain*strength/100)));
  };
  function sync(el:HTMLElement,settled=false){
   const rect=el.getBoundingClientRect();if(rect.width<2||rect.height<2)return;
   const level=materialLevel(el),profile=GLASS_PROFILES[level];el.dataset.glassLevel=level;
   if(level==='surface'||el.matches('.app>aside'))el.dataset.glassPlane='background';
   el.dataset.material=el.matches('.glass-settings,.glass-menu-layer,.glass-action-menu')?'transient':el.matches('nav.motion-glass,.segment-lens,.glass-lens-surface')?'clear':'regular';
   let entry=entries.get(el);
   if(!entry){entry={filter:null,key:'',scale:0,drive:0,press:0};entries.set(el,entry);resize.observe(el);el.dataset.rfGlass=enabled()?'svg':transparency.matches||contrast.matches?'opaque':'frosted'}
   el.dataset.rfGlass=enabled()?'svg':transparency.matches||contrast.matches?'opaque':'frosted';
   if(!enabled())return;
   const radius=parseFloat(getComputedStyle(el).borderTopLeftRadius)||26;
   const key=level+':'+[Math.round(rect.width/4)*4,Math.round(rect.height/4)*4,Math.round(radius)].join(':');
   if(entry.key===key){scaleFor(el,entry.scale);return}
   // Keep the existing map through spring/drag frames; rebuild once the lens settles.
   if(entry.key&&!settled&&el.matches('.segment-lens,.glass-lens-surface')){clearTimeout(pending.get(el));pending.set(el,window.setTimeout(()=>{pending.delete(el);if(el.isConnected)sync(el,true)},120));return}
   let map=cache.get(key);if(!map){const ratio=Math.min(1,640/Math.max(rect.width,rect.height));map=createLiquidGlassDisplacementMap({width:rect.width*ratio,height:rect.height*ratio,radius:radius*ratio,profile:'soft',magnify:profile.magnify,bend:profile.bend,spread:.58,bezelRatio:profile.bezelRatio,supersample:2});map={...map,scale:map.scale/ratio};if(cache.size>=32)cache.delete(cache.keys().next().value!);cache.set(key,map)}
   if(!map.url)return;
   if(!entry.filter){entry.filter=document.createElementNS(ns,'filter');entry.filter.id=`runflow-material-${++id}`;for(const [k,v]of Object.entries({x:'0%',y:'0%',width:'100%',height:'100%','color-interpolation-filters':'sRGB'}))entry.filter.setAttribute(k,v);defs.appendChild(entry.filter)}
   const image=document.createElementNS(ns,'feImage');image.setAttribute('href',map.url);image.setAttribute('width','100%');image.setAttribute('height','100%');image.setAttribute('preserveAspectRatio','none');image.setAttribute('result','map');
   const frost=document.createElementNS(ns,'feGaussianBlur');frost.setAttribute('in','SourceGraphic');frost.setAttribute('stdDeviation',String(profile.preblur));frost.setAttribute('result','softBackdrop');
   const nodes:SVGElement[]=[frost,image];
   const displacement=document.createElementNS(ns,'feDisplacementMap');
   for(const [k,v]of Object.entries({in:'softBackdrop',in2:'map',xChannelSelector:'R',yChannelSelector:'G'}))displacement.setAttribute(k,v);
   nodes.push(displacement);
   entry.filter.replaceChildren(...nodes);entry.key=key;entry.scale=map.scale;scaleFor(el,map.scale);el.style.setProperty('--rf-backdrop',`url("#${entry.filter.id}")`);
  }
  function scan(){frame=0;for(const [el,e]of entries)if(!el.isConnected){resize.unobserve(el);e.filter?.remove();entries.delete(el)}
   document.querySelectorAll<HTMLElement>('.app nav.motion-glass,.app .headeractions,.app .toolbar>.live,.app .toolbar>select,.app .glass-settings,.app .scalecontrol select,.app .comparequick button,.app .glassbutton,.app .heroactions>button,.app .choices,.app .modalfoot,.app .segment-lens,.app .glass-lens-surface,.app .progress-series-controls button,.app .chartcontrols select,.app .glass-select-trigger,.glass-menu-layer,.glass-action-menu').forEach(el=>sync(el));
   document.querySelector('.app')?.setAttribute('data-lg-role','stage');scrollMaterial();
  }
  function scrollMaterial(){scrollFrame=0;
   const main=document.querySelector('.app>main');if(!main)return;
   // Check nearby content only: avoid repeated viewport-wide geometry walks while scrolling.
   const candidates=Array.from(main.querySelectorAll<HTMLElement>('.panel,.dailyhero,.stats>article,.journal tbody tr')).map(el=>el.getBoundingClientRect()).filter(r=>r.bottom>=0&&r.top<=innerHeight);
   document.querySelectorAll<HTMLElement>('.app nav.motion-glass,.app .headeractions,.app .toolbar').forEach(el=>{
    const r=el.getBoundingClientRect();const crossing=candidates.some(c=>c.bottom>r.top&&c.top<r.bottom&&c.right>r.left&&c.left<r.right);
    const overlap=String(crossing);if(el.dataset.scrollOverlap!==overlap){el.style.setProperty('--rf-scroll-density',String(crossing?.12:0));el.dataset.scrollOverlap=overlap;}
   });
  }
  function scrolling(){if(!scrollFrame)scrollFrame=requestAnimationFrame(scrollMaterial);clearTimeout(scrollTimer);document.documentElement.dataset.glassScrolling='true';scrollTimer=window.setTimeout(()=>{delete document.documentElement.dataset.glassScrolling;scrollMaterial()},140)}
  function schedule(){if(!frame)frame=requestAnimationFrame(scan)}
  function light(e:PointerEvent){const el=(e.target as Element)?.closest<HTMLElement>('[data-rf-glass]');if(!el)return;const r=el.getBoundingClientRect();el.style.setProperty('--rf-light-x',`${(e.clientX-r.left)/r.width*100}%`);el.style.setProperty('--rf-light-y',`${(e.clientY-r.top)/r.height*100}%`)}
  function motion(e:Event){const el=e.target as HTMLElement,entry=entries.get(el);if(!entry)return;const d=(e as CustomEvent<{drive:number;press:number}>).detail;entry.drive=Number.isFinite(d.drive)?d.drive:0;entry.press=Number.isFinite(d.press)?d.press:0;scaleFor(el,entry.scale)}
  function settings(e:Event){strength=(e as CustomEvent<number>).detail;for(const [el,v]of entries)scaleFor(el,v.scale)}
  // During a lens spring only its dimensions change. Avoid rescanning every
  // glass surface in the application on every ResizeObserver notification.
  const resize=new ResizeObserver(records=>{
   for(const record of records)resizeDirty.add(record.target as HTMLElement);
   if(!resizeFrame)resizeFrame=requestAnimationFrame(()=>{
    resizeFrame=0;
    let refreshDepth=false;
    for(const el of resizeDirty){
     if(!el.isConnected)continue;
     sync(el);
     if(!el.matches('.segment-lens,.glass-lens-surface'))refreshDepth=true;
    }
    resizeDirty.clear();
    if(refreshDepth)scrollMaterial();
   });
  }),mutation=new MutationObserver(schedule);mutation.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['open','aria-expanded']});
  transparency.addEventListener('change',schedule);contrast.addEventListener('change',schedule);window.addEventListener('scroll',scrolling,{passive:true,capture:true});window.addEventListener('resize',schedule);window.addEventListener('runflow:glass',settings);document.addEventListener('runflow:glass-motion',motion);document.addEventListener('pointermove',light,{passive:true});schedule();
  return()=>{for(const t of pending.values())clearTimeout(t);cancelAnimationFrame(frame);cancelAnimationFrame(scrollFrame);cancelAnimationFrame(resizeFrame);resizeDirty.clear();clearTimeout(scrollTimer);transparency.removeEventListener('change',schedule);contrast.removeEventListener('change',schedule);window.removeEventListener('scroll',scrolling,true);delete document.documentElement.dataset.glassScrolling;resize.disconnect();mutation.disconnect();window.removeEventListener('resize',schedule);window.removeEventListener('runflow:glass',settings);document.removeEventListener('runflow:glass-motion',motion);document.removeEventListener('pointermove',light);for(const el of entries.keys()){delete el.dataset.rfGlass;delete el.dataset.material;delete el.dataset.glassLevel;delete el.dataset.glassPlane;el.style.removeProperty('--rf-backdrop')}svg.remove()};
 },[]);return null;
}
