'use client';
import {useEffect,useId,useLayoutEffect,useRef,useState,type KeyboardEvent} from 'react';
import {animateGlassMenu} from '../lib/animate-glass-menu';
import {createPortal} from 'react-dom';
import {MoreHorizontal,type LucideIcon} from 'lucide-react';

export type GlassAction={id:string;label:string;onSelect:()=>void;icon?:LucideIcon;destructive?:boolean;disabled?:boolean};

export default function GlassActionMenu({label,actions}:{label:string;actions:GlassAction[]}){
 const id=useId(),trigger=useRef<HTMLButtonElement>(null),panel=useRef<HTMLDivElement>(null);
 const anim=useRef<Animation|null>(null),opening=useRef(false);
 const [open,setOpen]=useState(false),[present,setPresent]=useState(false);
 const show=()=>{opening.current=true;setPresent(true);setOpen(true)};
 const close=()=>setOpen(false);
 useLayoutEffect(()=>{
  const el=panel.current,button=trigger.current;
  if(!el||!button||!present)return;
  const old=anim.current;

  const rect=button.getBoundingClientRect();
  const width=Math.min(window.innerWidth-24,Math.max(240,rect.width));
  el.style.width=`${width}px`;
  el.style.maxHeight=`${Math.max(60,window.innerHeight-24)}px`;
  const content=el.firstElementChild as HTMLElement|null;if(content)content.style.width=Math.max(0,width-16)+'px';
  const height=Math.min(innerHeight-24,(content?.scrollHeight??el.scrollHeight)+16);
  const left=Math.max(12,Math.min(window.innerWidth-width-12,rect.right-width));
  const below=window.innerHeight-rect.bottom>=Math.min(height+10,210)||rect.top<height+20;
  const top=Math.max(12,Math.min(window.innerHeight-height-12,below?rect.bottom+8:rect.top-height-8));
  el.style.left=`${left}px`;el.style.top=`${top}px`;
  el.dataset.expanded=String(open);
  anim.current=animateGlassMenu(el,button,open,width,height,left,top,old,()=>{if(!open){anim.current=null;setPresent(false)}});
  if(open&&opening.current){opening.current=false;el.querySelector<HTMLElement>('[role="menuitem"]:not([aria-disabled="true"])')?.focus()}
 },[open,present]);
 useEffect(()=>()=>anim.current?.cancel(),[]);
 useEffect(()=>{
  if(!open)return;
  const outside=(e:PointerEvent)=>{if(!trigger.current?.contains(e.target as Node)&&!panel.current?.contains(e.target as Node))close()};
  const scrolled=(e:Event)=>{if(!panel.current?.contains(e.target as Node))close()};
  document.addEventListener('pointerdown',outside);
  window.addEventListener('scroll',scrolled,true);
  window.addEventListener('resize',close);
  return()=>{document.removeEventListener('pointerdown',outside);window.removeEventListener('scroll',scrolled,true);window.removeEventListener('resize',close)};
 },[open]);
 function onKey(e:KeyboardEvent<HTMLDivElement>){
  if(e.key==='Escape'||e.key==='Tab') {if(e.key==='Escape')e.preventDefault();close();trigger.current?.focus();return}
  if(!['ArrowDown','ArrowUp','Home','End'].includes(e.key))return;
  e.preventDefault();
  const items=Array.from(panel.current?.querySelectorAll<HTMLButtonElement>('[role=menuitem]:not(:disabled)')||[]);
  if(!items.length)return;
  const i=items.indexOf(document.activeElement as HTMLButtonElement);
  const next=e.key==='Home'?0:e.key==='End'?items.length-1:(i+(e.key==='ArrowDown'?1:-1)+items.length)%items.length;
  items[next]?.focus();
 }
 return <>
  <button type="button" ref={trigger} className="glass-action-trigger iconbutton" aria-label={label} aria-haspopup="menu" aria-expanded={open} aria-controls={present?id:undefined} onClick={()=>open?close():show()} onKeyDown={e=>{if(e.key==='ArrowDown'){e.preventDefault();show()}}}>
   <MoreHorizontal size={20}/>
  </button>
  {present&&createPortal(<div ref={panel} id={id} className="glass-action-menu" role="menu" aria-label={label} aria-hidden={!open} inert={!open} onKeyDown={onKey} style={{pointerEvents:open?'auto':'none',transformOrigin:'top right'}}><div className="glass-action-items">{actions.map(action=><button key={action.id} type="button" role="menuitem" className={action.destructive?'is-destructive':''} disabled={action.disabled} tabIndex={-1} onClick={()=>{close();action.onSelect();trigger.current?.focus()}}><span>{action.label}</span>{action.icon&&<action.icon size={17} strokeWidth={1.8}/>}</button>)}</div></div>,document.body)}
 </>;
}
