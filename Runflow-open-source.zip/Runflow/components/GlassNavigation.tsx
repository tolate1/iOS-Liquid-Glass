'use client';
import {useEffect,useLayoutEffect,useRef,useState,type PointerEvent} from 'react';
import {navigationHit,sameNavigationGeometry} from '../lib/navigation-hit';
import {dockAnchor,dockPresentation} from '../lib/dock-geometry';
import {segmentResistance} from '../lib/segment-geometry';
import {sampleVelocity,releaseVelocity} from '../lib/gesture-sampling';
import {useGlassMotion} from '../hooks/useGlassMotion';
import {useLensShape} from '../hooks/useLensShape';
import {useFrameSpring} from '../hooks/useFrameSpring';
import {motion,useMotionValue,useTransform,useReducedMotion,type MotionStyle} from 'motion/react';
import {LayoutDashboard,List,TrendingUp,GitCompareArrows,Target} from 'lucide-react';
const items=[{Icon:LayoutDashboard,value:'Обзор',label:'Сегодня'},{Icon:List,value:'Тренировки',label:'Журнал'},{Icon:TrendingUp,value:'Прогресс',label:'Прогресс'},{Icon:GitCompareArrows,value:'Сравнение',label:'Сравнить'},{Icon:Target,value:'Цели и уровни',label:'Цели'}];
type Gesture={id:number;start:number;origin:number;horizontal:boolean;moved:boolean};
export default function GlassNavigation({active,onChange,count,experimental=true}:{active:string;onChange:(tab:string)=>void;count:number;experimental?:boolean}){
 const [visualActive,setVisualActive]=useState(active),[dragging,setDragging]=useState(false);
 useEffect(()=>setVisualActive(active),[active]);
 const nav=useRef<HTMLElement>(null),buttons=useRef<Record<string,HTMLButtonElement|null>>({});
 const initialized=useRef(false),geometry=useRef<number[]>([]),gesture=useRef<Gesture|null>(null),suppressClick=useRef(0);
 const reduce=useReducedMotion();
 // Coordinates are button centres, not left edges with hard-coded visual offsets.
 const x=useFrameSpring(0,{stiffness:220,damping:25,mass:1.1}),y=useFrameSpring(0,{stiffness:220,damping:25,mass:1.1});
 const baseW=useMotionValue(0),baseH=useMotionValue(0),sceneW=useMotionValue(0),sceneH=useMotionValue(0);
 const pressed=useFrameSpring(0,{stiffness:350,damping:24}),stretch=useFrameSpring(0,{stiffness:220,damping:20});
 const horizontal=useRef(true),axis=useMotionValue(1),lastPointer=useRef({position:0,time:0,speed:0});
 const surface=useRef<HTMLDivElement>(null),material=useRef<HTMLDivElement>(null);useGlassMotion(surface,stretch.value,pressed.value);useGlassMotion(material,stretch.value,pressed.value);
 const shape=useLensShape(baseW,baseH,stretch.value,pressed.value,axis,'dock');
 const presentation=useTransform(()=>{
  const left=x.get()-baseW.get()/2+shape.offsetX.get(),top=y.get()-baseH.get()/2+shape.offsetY.get();
  return axis.get()===1?dockPresentation(left,top,shape.width.get(),shape.height.get(),{width:sceneW.get(),height:sceneH.get()}):{left,top,width:shape.width.get(),height:shape.height.get()};
 });
 const renderX=useTransform(presentation,p=>p.left),renderY=useTransform(presentation,p=>p.top);
 const width=useTransform(presentation,p=>p.width),height=useTransform(presentation,p=>p.height);
 const [ready,setReady]=useState(false);
 function anchor(button:HTMLButtonElement){const root=nav.current!;return dockAnchor({left:button.offsetLeft,top:button.offsetTop,width:button.offsetWidth,height:button.offsetHeight},{width:root.clientWidth,height:root.clientHeight},horizontal.current)}
 function settle(value:string,velocity?:number){const b=buttons.current[value];if(!b||!nav.current)return;const a=anchor(b);
  baseW.set(a.width);baseH.set(a.height);
  if(reduce){x.jump(a.x);y.jump(a.y)}else if(velocity===undefined){x.set(a.x);y.set(a.y)}else if(horizontal.current){x.release(a.x,velocity);y.set(a.y)}else{y.release(a.y,velocity);x.set(a.x)}
 }
 useEffect(()=>{const update=()=>{if(!gesture.current)stretch.set(reduce?0:Math.max(-18,Math.min(18,(horizontal.current?x.getVelocity():y.getVelocity())*.065)))};
  const a=x.on('change',update),b=y.on('change',update);return()=>{a();b()};
 },[x,y,stretch,reduce]);
 // Shape and edge lighting use the same springs. Horizontal selection has no second backdrop filter.
 useLayoutEffect(()=>{const update=()=>{const root=nav.current;if(!root)return;
  const el=surface.current;if(el){el.style.setProperty('--rf-motion-energy',String(Math.min(1,Math.abs(stretch.get())/18)));el.style.setProperty('--rf-contact',String(Math.max(0,Math.min(1,pressed.get()))));}
 };const off=[renderX,renderY,width,height,stretch.value,pressed.value].map(v=>v.on('change',update));update();return()=>off.forEach(f=>f());},[renderX,renderY,width,height,stretch,pressed]);
 useEffect(()=>{if(reduce){pressed.jump(0);stretch.jump(0)}},[reduce,pressed,stretch]);
 useEffect(()=>{const cancel=()=>{const g=gesture.current;if(!g)return;gesture.current=null;const root=nav.current;
  if(root?.hasPointerCapture(g.id))root.releasePointerCapture(g.id);
  pressed.set(0);stretch.set(0);setDragging(false);settle(visualActive);suppressClick.current=performance.now()+400;
 };const visibility=()=>{if(document.hidden)cancel()};window.addEventListener('blur',cancel);document.addEventListener('visibilitychange',visibility);
 return()=>{window.removeEventListener('blur',cancel);document.removeEventListener('visibilitychange',visibility)};
 },[visualActive,reduce]);
 useLayoutEffect(()=>{const measure=()=>{const root=nav.current,button=buttons.current[visualActive];if(!root||!button)return;
  const measured=[root.clientWidth,root.clientHeight,...items.flatMap(i=>{const b=buttons.current[i.value];return b?[b.offsetLeft,b.offsetTop,b.offsetWidth,b.offsetHeight]:[]})];
  if(gesture.current&&sameNavigationGeometry(geometry.current,measured))return;
  const resized=!sameNavigationGeometry(geometry.current,measured);geometry.current=measured;
  if(gesture.current){const g=gesture.current;gesture.current=null;if(root.hasPointerCapture(g.id))root.releasePointerCapture(g.id);pressed.set(0);stretch.set(0);setDragging(false);suppressClick.current=performance.now()+400;}
  horizontal.current=buttons.current[items[4].value]?.offsetLeft!==buttons.current[items[0].value]?.offsetLeft;
  axis.set(horizontal.current?1:0);root.dataset.dockAxis=horizontal.current?'horizontal':'vertical';
  root.style.setProperty('--dock-radius',horizontal.current?root.clientHeight/2+'px':'24px');
  sceneW.set(root.clientWidth);sceneH.set(root.clientHeight);const a=anchor(button);baseW.set(a.width);baseH.set(a.height);
  if(!initialized.current||reduce||resized){x.jump(a.x);y.jump(a.y);initialized.current=true}else{x.set(a.x);y.set(a.y)}
  setReady(true);
 };measure();const observer=new ResizeObserver(measure);if(nav.current)observer.observe(nav.current);window.addEventListener('resize',measure);
 return()=>{observer.disconnect();window.removeEventListener('resize',measure)};
 },[visualActive,reduce,x,y]);
 useEffect(()=>{if(process.env.NODE_ENV!=='development')return;const samples:number[][]=[];const record=()=>{samples.push([Math.round(renderX.get()*100)/100,Math.round(renderY.get()*100)/100]);if(samples.length>80)samples.shift();if(nav.current)nav.current.dataset.motionSamples=JSON.stringify(samples)};const a=renderX.on('change',record),b=renderY.on('change',record);return()=>{a();b()}},[renderX,renderY]);
 function beginDrag(e:PointerEvent<HTMLElement>){if(!e.isPrimary||(e.pointerType==='mouse'&&e.button!==0)||gesture.current)return;
  const root=nav.current;if(!root)return;const position=horizontal.current?e.clientX:e.clientY;
  lastPointer.current={position,time:performance.now(),speed:0};if(!reduce)pressed.set(1);
  // Keep an in-flight spring alive until a real drag takes over (L44 repeat-tap fix).
  gesture.current={id:e.pointerId,start:position,origin:horizontal.current?x.get():y.get(),horizontal:horizontal.current,moved:false};
  root.setPointerCapture(e.pointerId);setDragging(true);e.preventDefault();
 }
 function moveDrag(e:PointerEvent<HTMLElement>){const g=gesture.current;if(!g||g.id!==e.pointerId)return;
  const position=g.horizontal?e.clientX:e.clientY,delta=position-g.start;
  if(!g.moved){if(Math.abs(delta)<=3){e.preventDefault();return}g.moved=true;g.origin=(g.horizontal?x.get():y.get())-Math.sign(delta)*3;}
  const now=performance.now(),speed=experimental?sampleVelocity(position,lastPointer.current.position,now,lastPointer.current.time)/1000:(position-lastPointer.current.position)/Math.max(8,now-lastPointer.current.time);
  lastPointer.current={position,time:now,speed};if(!reduce)stretch.set(Math.max(-18,Math.min(18,speed*18)));
  const coordinates=items.flatMap(i=>{const b=buttons.current[i.value];if(!b)return[];const a=anchor(b);return[g.horizontal?a.x:a.y]});
  const value=experimental?segmentResistance(g.origin+delta,Math.min(...coordinates),Math.max(...coordinates)):Math.max(Math.min(...coordinates),Math.min(Math.max(...coordinates),g.origin+delta));
  if(g.horizontal)x.jump(value);else y.jump(value);e.preventDefault();
 }
 function finishDrag(e:PointerEvent<HTMLElement>,cancelled=false){const g=gesture.current;if(!g||g.id!==e.pointerId)return;
  gesture.current=null;pressed.set(0);stretch.set(0);setDragging(false);
  if(nav.current?.hasPointerCapture(e.pointerId))nav.current.releasePointerCapture(e.pointerId);
  let next=visualActive;
  if(g.moved&&!cancelled){const position=g.horizontal?x.get():y.get();next=items.reduce((best,item)=>{const a=buttons.current[best.value],b=buttons.current[item.value];if(!a||!b)return best;const aa=anchor(a),ab=anchor(b);return Math.abs((g.horizontal?ab.x:ab.y)-position)<Math.abs((g.horizontal?aa.x:aa.y)-position)?item:best},items[0]).value;
  }else if(!cancelled){next=navigationHit(e.clientX,e.clientY,items.flatMap(item=>{const b=buttons.current[item.value];return b?[{value:item.value,...b.getBoundingClientRect().toJSON()}]:[]}))||visualActive;}
  const velocity=experimental?releaseVelocity(lastPointer.current.speed*1000,lastPointer.current.time,performance.now(),cancelled||!g.moved,!!reduce):!reduce&&g.moved&&!cancelled&&performance.now()-lastPointer.current.time<100?lastPointer.current.speed*1000:0;
  settle(next,g.moved?velocity:undefined);suppressClick.current=performance.now()+400;
  setVisualActive(next);if(!cancelled&&next!==visualActive)onChange(next);
 }
 return <nav ref={nav} className={'glass-navigation motion-glass'+(dragging?' is-dragging':'')} data-dock-version="l49"
  onPointerDown={beginDrag} onPointerMove={moveDrag} onPointerUp={e=>finishDrag(e)} onPointerCancel={e=>finishDrag(e,true)} onLostPointerCapture={e=>finishDrag(e,true)}
  onClickCapture={e=>{if(e.detail>0&&performance.now()<suppressClick.current){e.preventDefault();e.stopPropagation()}}} data-lg-role="dock" aria-label="Разделы дневника">
  <div ref={material} className="dock-material" aria-hidden="true"/>
  {items.map(({Icon,value,label})=><button ref={el=>{buttons.current[value]=el}} key={value} aria-current={visualActive===value?'page':undefined} className={visualActive===value?'active':''} onClick={()=>{if(value!==visualActive){setVisualActive(value);onChange(value)}}}><span className="nav-visual"><Icon size={19}/><span>{label}</span>{value==='Тренировки'&&<small>{count}</small>}</span></button>)}
  <motion.div className="glass-lens is-ready" aria-hidden="true" style={{x:renderX,y:renderY,width,height,borderRadius:shape.radius,skewX:shape.skewX,skewY:shape.skewY,opacity:ready?1:0}}>
   <motion.div ref={surface} className="glass-lens-surface" style={{scale:shape.scale,'--light-angle':shape.angle,'--rf-light-x':shape.lightX,'--rf-light-y':shape.lightY} as MotionStyle}><div className="lens-caustic"/><div className="lens-touch-light"/></motion.div>
  </motion.div>
 </nav>;
}
